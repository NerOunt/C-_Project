using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace BuildingMaterialsStoreAccounting
{
    public partial class FormDocuments : Form
    {
        private NpgsqlConnection con;

        public FormDocuments(NpgsqlConnection con)
        {
            InitializeComponent();
            this.con = con;
            comboBoxIncomingDepartment.SelectedIndexChanged += new EventHandler(comboBoxIncomingDepartment_SelectedIndexChanged);
            comboBoxSalesDepartment.SelectedIndexChanged += new EventHandler(comboBoxSalesDepartment_SelectedIndexChanged);
        }

        private void FormDocuments_Load(object sender, EventArgs e)
        {
            LoadCombos();
            LoadIncomingInvoices();
            LoadSalesReceipts();
        }

        private void LoadCombos()
        {
            LoadCombo(comboBoxIncomingSupplier, "SELECT id, name FROM suppliers ORDER BY name;");
            LoadCombo(comboBoxIncomingDepartment, "SELECT id, name FROM departments ORDER BY name;");
            LoadCombo(comboBoxSalesDepartment, "SELECT id, name FROM departments ORDER BY name;");
            LoadCombo(comboBoxSalesPaymentType, "SELECT id, name FROM payment_types ORDER BY name;");
            LoadIncomingProductsByDepartment();
            LoadSalesProductsByDepartment();
        }

        private void LoadCombo(ComboBox comboBox, string sql)
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataTable table = new DataTable();
                adapter.Fill(table);
                comboBox.DataSource = table;
                comboBox.DisplayMember = "name";
                comboBox.ValueMember = "id";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private int GetId(DataGridView grid)
        {
            if (grid.CurrentRow == null) return -1;
            return Convert.ToInt32(grid.CurrentRow.Cells["ID"].Value);
        }

        private int GetComboId(ComboBox comboBox)
        {
            if (comboBox.SelectedValue == null) return -1;
            if (comboBox.SelectedValue is DataRowView)
            {
                DataRowView row = (DataRowView)comboBox.SelectedValue;
                return Convert.ToInt32(row["id"]);
            }
            return Convert.ToInt32(comboBox.SelectedValue);
        }

        private int GetIncomingDepartmentId()
        {
            return GetComboId(comboBoxIncomingDepartment);
        }

        private int GetSalesDepartmentId()
        {
            return GetComboId(comboBoxSalesDepartment);
        }

        private int GetSelectedIncomingInvoiceDepartmentId()
        {
            if (dataGridViewIncomingInvoices.CurrentRow == null ||
                !dataGridViewIncomingInvoices.Columns.Contains("department_id"))
            {
                return -1;
            }

            return Convert.ToInt32(dataGridViewIncomingInvoices.CurrentRow.Cells["department_id"].Value);
        }

        private int GetSelectedSalesReceiptDepartmentId()
        {
            if (dataGridViewSalesReceipts.CurrentRow == null ||
                !dataGridViewSalesReceipts.Columns.Contains("department_id"))
            {
                return -1;
            }

            return Convert.ToInt32(dataGridViewSalesReceipts.CurrentRow.Cells["department_id"].Value);
        }

        private void SelectRowById(DataGridView grid, int id)
        {
            foreach (DataGridViewRow row in grid.Rows)
            {
                if (Convert.ToInt32(row.Cells["ID"].Value) == id)
                {
                    row.Selected = true;
                    grid.CurrentCell = row.Cells["ID"];
                    break;
                }
            }
        }

        private void LoadProductsByDepartment(ComboBox comboBox, int departmentId)
        {
            try
            {
                DataTable table = new DataTable();
                if (departmentId == -1)
                {
                    comboBox.DataSource = table;
                    return;
                }

                string sql =
                    "SELECT products.id, products.name " +
                    "FROM products " +
                    "JOIN department_product_types ON products.product_type_id = department_product_types.product_type_id " +
                    "WHERE department_product_types.department_id = :department_id " +
                    "ORDER BY products.name;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                adapter.SelectCommand.Parameters.AddWithValue("department_id", departmentId);
                adapter.Fill(table);
                comboBox.DataSource = table;
                comboBox.DisplayMember = "name";
                comboBox.ValueMember = "id";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadIncomingProductsByDepartment()
        {
            LoadProductsByDepartment(comboBoxIncomingProduct, GetIncomingDepartmentId());
        }

        private void LoadIncomingProductsBySelectedInvoice()
        {
            LoadProductsByDepartment(comboBoxIncomingProduct, GetSelectedIncomingInvoiceDepartmentId());
        }

        private void LoadSalesProductsByDepartment()
        {
            LoadProductsByDepartment(comboBoxSalesProduct, GetSalesDepartmentId());
        }

        private void LoadSalesProductsBySelectedReceipt()
        {
            LoadProductsByDepartment(comboBoxSalesProduct, GetSelectedSalesReceiptDepartmentId());
        }

        private void LoadIncomingInvoices()
        {
            try
            {
                string sql =
                    "SELECT incoming_invoices.id AS ID, incoming_invoices.invoice_date AS data, " +
                    "suppliers.name AS supplier, departments.name AS department, incoming_invoices.total_sum AS total_sum, " +
                    "incoming_invoices.supplier_id, incoming_invoices.department_id " +
                    "FROM incoming_invoices " +
                    "JOIN suppliers ON incoming_invoices.supplier_id = suppliers.id " +
                    "JOIN departments ON incoming_invoices.department_id = departments.id " +
                    "ORDER BY incoming_invoices.id;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewIncomingInvoices.DataSource = ds.Tables[0];
                dataGridViewIncomingInvoices.Columns["ID"].HeaderText = "Номер";
                dataGridViewIncomingInvoices.Columns["data"].HeaderText = "Дата";
                dataGridViewIncomingInvoices.Columns["supplier"].HeaderText = "Поставщик";
                dataGridViewIncomingInvoices.Columns["department"].HeaderText = "Отдел";
                dataGridViewIncomingInvoices.Columns["total_sum"].HeaderText = "Сумма";
                dataGridViewIncomingInvoices.Columns["supplier_id"].Visible = false;
                dataGridViewIncomingInvoices.Columns["department_id"].Visible = false;
                LoadIncomingProductsBySelectedInvoice();
                LoadIncomingItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadIncomingItems()
        {
            int invoiceId = GetId(dataGridViewIncomingInvoices);
            if (invoiceId == -1)
            {
                dataGridViewIncomingItems.DataSource = null;
                return;
            }

            try
            {
                string sql =
                    "SELECT incoming_invoice_items.id AS ID, products.name AS product, products.ed AS ed, " +
                    "incoming_invoice_items.quantity AS quantity, incoming_invoice_items.price AS price, " +
                    "incoming_invoice_items.quantity * incoming_invoice_items.price AS sum " +
                    "FROM incoming_invoice_items " +
                    "JOIN products ON incoming_invoice_items.product_id = products.id " +
                    "WHERE incoming_invoice_items.incoming_invoice_id = :invoice_id " +
                    "ORDER BY incoming_invoice_items.id;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                adapter.SelectCommand.Parameters.AddWithValue("invoice_id", invoiceId);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridViewIncomingItems.DataSource = table;
                SetItemHeaders(dataGridViewIncomingItems);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewIncomingInvoices_SelectionChanged(object sender, EventArgs e)
        {
            int departmentId = GetSelectedIncomingInvoiceDepartmentId();
            if (departmentId != -1)
            {
                comboBoxIncomingDepartment.SelectedValue = departmentId;
            }
            LoadIncomingProductsBySelectedInvoice();
            LoadIncomingItems();
        }

        private void comboBoxIncomingDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadIncomingProductsByDepartment();
        }

        private void buttonAddIncomingInvoice_Click(object sender, EventArgs e)
        {
            if (comboBoxIncomingSupplier.SelectedValue == null || comboBoxIncomingDepartment.SelectedValue == null) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand(
                    "INSERT INTO incoming_invoices (supplier_id, department_id, invoice_date, total_sum) " +
                    "VALUES (:supplier_id, :department_id, :invoice_date, 0) RETURNING id;", con);
                cmd.Parameters.AddWithValue("supplier_id", Convert.ToInt32(comboBoxIncomingSupplier.SelectedValue));
                cmd.Parameters.AddWithValue("department_id", Convert.ToInt32(comboBoxIncomingDepartment.SelectedValue));
                cmd.Parameters.AddWithValue("invoice_date", dateTimePickerIncomingDate.Value.Date);
                int newId = Convert.ToInt32(cmd.ExecuteScalar());
                LoadIncomingInvoices();
                SelectRowById(dataGridViewIncomingInvoices, newId);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDeleteIncomingInvoice_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewIncomingInvoices);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM incoming_invoices WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadIncomingInvoices();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonAddIncomingItem_Click(object sender, EventArgs e)
        {
            int invoiceId = GetId(dataGridViewIncomingInvoices);
            if (invoiceId == -1 || comboBoxIncomingProduct.SelectedValue == null) return;
            decimal quantity;
            decimal price;
            if (!decimal.TryParse(textBoxIncomingQuantity.Text, out quantity) || !decimal.TryParse(textBoxIncomingPrice.Text, out price)) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand(
                    "INSERT INTO incoming_invoice_items (incoming_invoice_id, product_id, quantity, price) " +
                    "VALUES (:incoming_invoice_id, :product_id, :quantity, :price);", con);
                cmd.Parameters.AddWithValue("incoming_invoice_id", invoiceId);
                cmd.Parameters.AddWithValue("product_id", Convert.ToInt32(comboBoxIncomingProduct.SelectedValue));
                cmd.Parameters.AddWithValue("quantity", quantity);
                cmd.Parameters.AddWithValue("price", price);
                cmd.ExecuteNonQuery();
                LoadIncomingInvoices();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDeleteIncomingItem_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewIncomingItems);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM incoming_invoice_items WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadIncomingInvoices();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadSalesReceipts()
        {
            try
            {
                string sql =
                    "SELECT sales_receipts.id AS ID, sales_receipts.receipt_date AS data, " +
                    "departments.name AS department, payment_types.name AS payment_type, sales_receipts.total_sum AS total_sum, " +
                    "sales_receipts.department_id, sales_receipts.payment_type_id " +
                    "FROM sales_receipts " +
                    "JOIN departments ON sales_receipts.department_id = departments.id " +
                    "JOIN payment_types ON sales_receipts.payment_type_id = payment_types.id " +
                    "ORDER BY sales_receipts.id;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewSalesReceipts.DataSource = ds.Tables[0];
                dataGridViewSalesReceipts.Columns["ID"].HeaderText = "Номер";
                dataGridViewSalesReceipts.Columns["data"].HeaderText = "Дата";
                dataGridViewSalesReceipts.Columns["department"].HeaderText = "Отдел";
                dataGridViewSalesReceipts.Columns["payment_type"].HeaderText = "Тип оплаты";
                dataGridViewSalesReceipts.Columns["total_sum"].HeaderText = "Сумма";
                dataGridViewSalesReceipts.Columns["department_id"].Visible = false;
                dataGridViewSalesReceipts.Columns["payment_type_id"].Visible = false;
                LoadSalesProductsBySelectedReceipt();
                LoadSalesItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadSalesItems()
        {
            int receiptId = GetId(dataGridViewSalesReceipts);
            if (receiptId == -1)
            {
                dataGridViewSalesItems.DataSource = null;
                return;
            }

            try
            {
                string sql =
                    "SELECT sales_receipt_items.id AS ID, products.name AS product, products.ed AS ed, " +
                    "sales_receipt_items.quantity AS quantity, sales_receipt_items.price AS price, " +
                    "sales_receipt_items.quantity * sales_receipt_items.price AS sum " +
                    "FROM sales_receipt_items " +
                    "JOIN products ON sales_receipt_items.product_id = products.id " +
                    "WHERE sales_receipt_items.sales_receipt_id = :receipt_id " +
                    "ORDER BY sales_receipt_items.id;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                adapter.SelectCommand.Parameters.AddWithValue("receipt_id", receiptId);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridViewSalesItems.DataSource = table;
                SetItemHeaders(dataGridViewSalesItems);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewSalesReceipts_SelectionChanged(object sender, EventArgs e)
        {
            int departmentId = GetSelectedSalesReceiptDepartmentId();
            if (departmentId != -1)
            {
                comboBoxSalesDepartment.SelectedValue = departmentId;
            }
            LoadSalesProductsBySelectedReceipt();
            LoadSalesItems();
        }

        private void comboBoxSalesDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadSalesProductsByDepartment();
        }

        private void buttonAddSalesReceipt_Click(object sender, EventArgs e)
        {
            if (comboBoxSalesDepartment.SelectedValue == null || comboBoxSalesPaymentType.SelectedValue == null) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand(
                    "INSERT INTO sales_receipts (department_id, payment_type_id, receipt_date, total_sum) " +
                    "VALUES (:department_id, :payment_type_id, :receipt_date, 0) RETURNING id;", con);
                cmd.Parameters.AddWithValue("department_id", Convert.ToInt32(comboBoxSalesDepartment.SelectedValue));
                cmd.Parameters.AddWithValue("payment_type_id", Convert.ToInt32(comboBoxSalesPaymentType.SelectedValue));
                cmd.Parameters.AddWithValue("receipt_date", dateTimePickerSalesDate.Value.Date);
                int newId = Convert.ToInt32(cmd.ExecuteScalar());
                LoadSalesReceipts();
                SelectRowById(dataGridViewSalesReceipts, newId);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDeleteSalesReceipt_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewSalesReceipts);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM sales_receipts WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadSalesReceipts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonAddSalesItem_Click(object sender, EventArgs e)
        {
            int receiptId = GetId(dataGridViewSalesReceipts);
            if (receiptId == -1 || comboBoxSalesProduct.SelectedValue == null) return;
            decimal quantity;
            decimal price;
            if (!decimal.TryParse(textBoxSalesQuantity.Text, out quantity) || !decimal.TryParse(textBoxSalesPrice.Text, out price)) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand(
                    "INSERT INTO sales_receipt_items (sales_receipt_id, product_id, quantity, price) " +
                    "VALUES (:sales_receipt_id, :product_id, :quantity, :price);", con);
                cmd.Parameters.AddWithValue("sales_receipt_id", receiptId);
                cmd.Parameters.AddWithValue("product_id", Convert.ToInt32(comboBoxSalesProduct.SelectedValue));
                cmd.Parameters.AddWithValue("quantity", quantity);
                cmd.Parameters.AddWithValue("price", price);
                cmd.ExecuteNonQuery();
                LoadSalesReceipts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDeleteSalesItem_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewSalesItems);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM sales_receipt_items WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadSalesReceipts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SetItemHeaders(DataGridView grid)
        {
            grid.Columns["ID"].HeaderText = "Номер";
            grid.Columns["product"].HeaderText = "Товар";
            grid.Columns["ed"].HeaderText = "Ед. изм.";
            grid.Columns["quantity"].HeaderText = "Количество";
            grid.Columns["price"].HeaderText = "Цена";
            grid.Columns["sum"].HeaderText = "Сумма";
        }

        private void buttonRefreshIncoming_Click(object sender, EventArgs e)
        {
            LoadCombos();
            LoadIncomingInvoices();
        }

        private void buttonRefreshSales_Click(object sender, EventArgs e)
        {
            LoadCombos();
            LoadSalesReceipts();
        }
    }
}
