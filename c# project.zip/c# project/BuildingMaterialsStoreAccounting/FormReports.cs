using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace BuildingMaterialsStoreAccounting
{
    public partial class FormReports : Form
    {
        private NpgsqlConnection con;

        public FormReports(NpgsqlConnection con)
        {
            InitializeComponent();
            this.con = con;
        }

        private void FormReports_Load(object sender, EventArgs e)
        {
            LoadProductTypes();
        }

        private void LoadProductTypes()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id, name FROM product_types ORDER BY name;", con);
                DataTable table = new DataTable();
                adapter.Fill(table);
                comboBoxProductType.DataSource = table;
                comboBoxProductType.DisplayMember = "name";
                comboBoxProductType.ValueMember = "id";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonCreateTurnoverReport_Click(object sender, EventArgs e)
        {
            if (comboBoxProductType.SelectedValue == null) return;

            try
            {
                int productTypeId = GetSelectedProductTypeId();
                if (productTypeId == -1) return;

                string sql =
                    "SELECT d.name AS department, pt.name AS product_type, p.name AS product, " +
                    "COALESCE((SELECT SUM(iii.quantity) FROM incoming_invoice_items iii " +
                    "JOIN incoming_invoices ii ON iii.incoming_invoice_id = ii.id " +
                    "WHERE ii.department_id = d.id AND iii.product_id = p.id AND ii.invoice_date < :date_from), 0) - " +
                    "COALESCE((SELECT SUM(sri.quantity) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "WHERE sr.department_id = d.id AND sri.product_id = p.id AND sr.receipt_date < :date_from), 0) AS start_balance, " +
                    "COALESCE((SELECT SUM(iii.quantity) FROM incoming_invoice_items iii " +
                    "JOIN incoming_invoices ii ON iii.incoming_invoice_id = ii.id " +
                    "WHERE ii.department_id = d.id AND iii.product_id = p.id AND ii.invoice_date BETWEEN :date_from AND :date_to), 0) AS incoming_quantity, " +
                    "COALESCE((SELECT SUM(sri.quantity) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "WHERE sr.department_id = d.id AND sri.product_id = p.id AND sr.receipt_date BETWEEN :date_from AND :date_to), 0) AS sales_quantity, " +
                    "COALESCE((SELECT SUM(iii.quantity * iii.price) FROM incoming_invoice_items iii " +
                    "JOIN incoming_invoices ii ON iii.incoming_invoice_id = ii.id " +
                    "WHERE ii.department_id = d.id AND iii.product_id = p.id AND ii.invoice_date BETWEEN :date_from AND :date_to), 0) AS incoming_sum, " +
                    "COALESCE((SELECT SUM(sri.quantity * sri.price) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "WHERE sr.department_id = d.id AND sri.product_id = p.id AND sr.receipt_date BETWEEN :date_from AND :date_to), 0) AS sales_sum " +
                    "FROM department_product_types dpt " +
                    "JOIN departments d ON dpt.department_id = d.id " +
                    "JOIN product_types pt ON dpt.product_type_id = pt.id " +
                    "JOIN products p ON p.product_type_id = pt.id " +
                    "WHERE dpt.product_type_id = :product_type_id " +
                    "ORDER BY d.name, p.name;";

                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                adapter.SelectCommand.Parameters.AddWithValue("date_from", dateTimePickerFrom.Value.Date);
                adapter.SelectCommand.Parameters.AddWithValue("date_to", dateTimePickerTo.Value.Date);
                adapter.SelectCommand.Parameters.AddWithValue("product_type_id", productTypeId);
                DataTable table = new DataTable();
                adapter.Fill(table);
                table.Columns.Add("end_balance", typeof(decimal));

                foreach (DataRow row in table.Rows)
                {
                    decimal startBalance = Convert.ToDecimal(row["start_balance"]);
                    decimal incomingQuantity = Convert.ToDecimal(row["incoming_quantity"]);
                    decimal salesQuantity = Convert.ToDecimal(row["sales_quantity"]);
                    row["end_balance"] = startBalance + incomingQuantity - salesQuantity;
                }

                dataGridViewTurnover.DataSource = table;
                dataGridViewTurnover.Columns["department"].HeaderText = "Отдел";
                dataGridViewTurnover.Columns["product_type"].HeaderText = "Вид товара";
                dataGridViewTurnover.Columns["product"].HeaderText = "Товар";
                dataGridViewTurnover.Columns["start_balance"].HeaderText = "Начальный остаток";
                dataGridViewTurnover.Columns["incoming_quantity"].HeaderText = "Приход за период";
                dataGridViewTurnover.Columns["sales_quantity"].HeaderText = "Расход за период";
                dataGridViewTurnover.Columns["end_balance"].HeaderText = "Конечный остаток";
                dataGridViewTurnover.Columns["incoming_sum"].HeaderText = "Сумма прихода";
                dataGridViewTurnover.Columns["sales_sum"].HeaderText = "Сумма продаж";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private int GetSelectedProductTypeId()
        {
            if (comboBoxProductType.SelectedValue == null) return -1;

            if (comboBoxProductType.SelectedValue is DataRowView)
            {
                DataRowView row = (DataRowView)comboBoxProductType.SelectedValue;
                return Convert.ToInt32(row["id"]);
            }

            return Convert.ToInt32(comboBoxProductType.SelectedValue);
        }

        private void buttonCreateDepartmentReport_Click(object sender, EventArgs e)
        {
            try
            {
                string sql =
                    "SELECT d.name AS department, " +
                    "COALESCE((SELECT SUM(iii.quantity * iii.price) FROM incoming_invoice_items iii " +
                    "JOIN incoming_invoices ii ON iii.incoming_invoice_id = ii.id " +
                    "WHERE ii.department_id = d.id AND ii.invoice_date BETWEEN :date_from AND :date_to), 0) AS incoming_sum, " +
                    "COALESCE((SELECT SUM(sri.quantity * sri.price) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "WHERE sr.department_id = d.id AND sr.receipt_date BETWEEN :date_from AND :date_to), 0) AS sales_sum, " +
                    "COALESCE((SELECT SUM(sri.quantity * sri.price) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "JOIN payment_types pt ON sr.payment_type_id = pt.id " +
                    "WHERE sr.department_id = d.id AND sr.receipt_date BETWEEN :date_from AND :date_to AND pt.name = 'Наличные'), 0) AS cash_sum, " +
                    "COALESCE((SELECT SUM(sri.quantity * sri.price) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "JOIN payment_types pt ON sr.payment_type_id = pt.id " +
                    "WHERE sr.department_id = d.id AND sr.receipt_date BETWEEN :date_from AND :date_to AND pt.name = 'Карта'), 0) AS card_sum " +
                    "FROM departments d ORDER BY d.name;";

                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                adapter.SelectCommand.Parameters.AddWithValue("date_from", dateTimePickerFrom2.Value.Date);
                adapter.SelectCommand.Parameters.AddWithValue("date_to", dateTimePickerTo2.Value.Date);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridViewDepartmentReport.DataSource = table;
                dataGridViewDepartmentReport.Columns["department"].HeaderText = "Отдел";
                dataGridViewDepartmentReport.Columns["incoming_sum"].HeaderText = "Сумма полученных товаров";
                dataGridViewDepartmentReport.Columns["sales_sum"].HeaderText = "Сумма продаж всего";
                dataGridViewDepartmentReport.Columns["cash_sum"].HeaderText = "Продажи наличными";
                dataGridViewDepartmentReport.Columns["card_sum"].HeaderText = "Продажи по карте";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonExcelTurnover_Click(object sender, EventArgs e)
        {
            ExportToExcel(dataGridViewTurnover, "Обороты и остатки", dateTimePickerFrom.Value, dateTimePickerTo.Value);
        }

        private void buttonExcelDepartmentReport_Click(object sender, EventArgs e)
        {
            ExportToExcel(dataGridViewDepartmentReport, "Отчёт по отделам", dateTimePickerFrom2.Value, dateTimePickerTo2.Value);
        }

        private void ExportToExcel(DataGridView grid, string title, DateTime dateFrom, DateTime dateTo)
        {
            try
            {
                Type excelType = Type.GetTypeFromProgID("Excel.Application");
                if (excelType == null)
                {
                    MessageBox.Show("Microsoft Excel не установлен на этом компьютере.");
                    return;
                }

                dynamic excelApp = Activator.CreateInstance(excelType);
                excelApp.Visible = true;
                dynamic workbook = excelApp.Workbooks.Add();
                dynamic worksheet = workbook.Worksheets[1];

                worksheet.Cells[1, 1] = title;
                worksheet.Cells[2, 1] = "Период: " + dateFrom.ToShortDateString() + " - " + dateTo.ToShortDateString();

                for (int j = 0; j < grid.Columns.Count; j++)
                {
                    worksheet.Cells[4, j + 1] = grid.Columns[j].HeaderText;
                }

                for (int i = 0; i < grid.Rows.Count; i++)
                {
                    if (grid.Rows[i].IsNewRow) continue;

                    for (int j = 0; j < grid.Columns.Count; j++)
                    {
                        worksheet.Cells[i + 5, j + 1] = Convert.ToString(grid.Rows[i].Cells[j].Value);
                    }
                }

                worksheet.Columns.AutoFit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
