using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace BuildingMaterialsStoreAccounting
{
    public partial class FormDirectories : Form
    {
        private NpgsqlConnection con;
        private TabPage tabDepartmentProductTypes;
        private DataGridView dataGridViewDepartmentProductTypes;
        private ComboBox comboBoxLinkDepartment;
        private ComboBox comboBoxLinkProductType;
        private Button buttonAddDepartmentProductType;
        private Button buttonDeleteDepartmentProductType;
        private Button buttonRefreshDepartmentProductTypes;

        public FormDirectories(NpgsqlConnection con)
        {
            InitializeComponent();
            CreateDepartmentProductTypesTab();
            this.con = con;
        }

        private void FormDirectories_Load(object sender, EventArgs e)
        {
            LoadAll();
        }

        private void LoadAll()
        {
            LoadDepartments();
            LoadProductTypes();
            LoadProductTypesCombo();
            LoadProducts();
            LoadSuppliers();
            LoadPaymentTypes();
            LoadDepartmentProductTypeCombos();
            LoadDepartmentProductTypes();
        }

        private void CreateDepartmentProductTypesTab()
        {
            tabDepartmentProductTypes = new TabPage();
            dataGridViewDepartmentProductTypes = new DataGridView();
            comboBoxLinkDepartment = new ComboBox();
            comboBoxLinkProductType = new ComboBox();
            buttonAddDepartmentProductType = new Button();
            buttonDeleteDepartmentProductType = new Button();
            buttonRefreshDepartmentProductTypes = new Button();

            Panel panel = new Panel();
            Label labelDepartment = new Label();
            Label labelProductType = new Label();

            tabDepartmentProductTypes.Text = "Виды по отделам";
            tabDepartmentProductTypes.Name = "tabDepartmentProductTypes";

            panel.Dock = DockStyle.Top;
            panel.Height = 70;

            labelDepartment.Text = "Отдел";
            labelDepartment.AutoSize = true;
            labelDepartment.Location = new System.Drawing.Point(10, 13);

            comboBoxLinkDepartment.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxLinkDepartment.Location = new System.Drawing.Point(80, 10);
            comboBoxLinkDepartment.Size = new System.Drawing.Size(220, 21);

            labelProductType.Text = "Вид товара";
            labelProductType.AutoSize = true;
            labelProductType.Location = new System.Drawing.Point(320, 13);

            comboBoxLinkProductType.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxLinkProductType.Location = new System.Drawing.Point(400, 10);
            comboBoxLinkProductType.Size = new System.Drawing.Size(220, 21);

            buttonAddDepartmentProductType.Text = "Добавить";
            buttonAddDepartmentProductType.SetBounds(650, 8, 100, 25);
            buttonAddDepartmentProductType.Click += new EventHandler(buttonAddDepartmentProductType_Click);

            buttonDeleteDepartmentProductType.Text = "Удалить";
            buttonDeleteDepartmentProductType.SetBounds(760, 8, 100, 25);
            buttonDeleteDepartmentProductType.Click += new EventHandler(buttonDeleteDepartmentProductType_Click);

            buttonRefreshDepartmentProductTypes.Text = "Обновить";
            buttonRefreshDepartmentProductTypes.SetBounds(870, 8, 100, 25);
            buttonRefreshDepartmentProductTypes.Click += new EventHandler(buttonRefreshDepartmentProductTypes_Click);

            dataGridViewDepartmentProductTypes.AllowUserToAddRows = false;
            dataGridViewDepartmentProductTypes.AllowUserToDeleteRows = false;
            dataGridViewDepartmentProductTypes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewDepartmentProductTypes.Dock = DockStyle.Fill;
            dataGridViewDepartmentProductTypes.MultiSelect = false;
            dataGridViewDepartmentProductTypes.ReadOnly = true;
            dataGridViewDepartmentProductTypes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            panel.Controls.Add(labelDepartment);
            panel.Controls.Add(comboBoxLinkDepartment);
            panel.Controls.Add(labelProductType);
            panel.Controls.Add(comboBoxLinkProductType);
            panel.Controls.Add(buttonAddDepartmentProductType);
            panel.Controls.Add(buttonDeleteDepartmentProductType);
            panel.Controls.Add(buttonRefreshDepartmentProductTypes);

            tabDepartmentProductTypes.Controls.Add(dataGridViewDepartmentProductTypes);
            tabDepartmentProductTypes.Controls.Add(panel);
            tabControl1.Controls.Add(tabDepartmentProductTypes);
        }

        private void LoadDepartments()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id AS ID, name, description FROM departments ORDER BY id;", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewDepartments.DataSource = ds.Tables[0];
                dataGridViewDepartments.Columns["ID"].HeaderText = "Номер";
                dataGridViewDepartments.Columns["name"].HeaderText = "Название";
                dataGridViewDepartments.Columns["description"].HeaderText = "Описание";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadProductTypes()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id AS ID, name FROM product_types ORDER BY id;", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewProductTypes.DataSource = ds.Tables[0];
                dataGridViewProductTypes.Columns["ID"].HeaderText = "Номер";
                dataGridViewProductTypes.Columns["name"].HeaderText = "Название";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadProductTypesCombo()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id, name FROM product_types ORDER BY name;", con);
                DataTable table = new DataTable();
                adapter.Fill(table);
                comboBoxProductType.DataSource = table;
                comboBoxProductType.DisplayMember = "name";
                comboBoxProductType.ValueMember = "id";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadProducts()
        {
            try
            {
                string sql =
                    "SELECT products.id AS ID, products.name AS name, products.ed AS ed, " +
                    "product_types.name AS product_type, products.product_type_id AS product_type_id " +
                    "FROM products JOIN product_types ON products.product_type_id = product_types.id " +
                    "ORDER BY products.id;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewProducts.DataSource = ds.Tables[0];
                dataGridViewProducts.Columns["ID"].HeaderText = "Номер";
                dataGridViewProducts.Columns["name"].HeaderText = "Наименование";
                dataGridViewProducts.Columns["ed"].HeaderText = "Ед. изм.";
                dataGridViewProducts.Columns["product_type"].HeaderText = "Вид товара";
                dataGridViewProducts.Columns["product_type_id"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadSuppliers()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id AS ID, name, address, phone FROM suppliers ORDER BY id;", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewSuppliers.DataSource = ds.Tables[0];
                dataGridViewSuppliers.Columns["ID"].HeaderText = "Номер";
                dataGridViewSuppliers.Columns["name"].HeaderText = "Название";
                dataGridViewSuppliers.Columns["address"].HeaderText = "Адрес";
                dataGridViewSuppliers.Columns["phone"].HeaderText = "Телефон";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadPaymentTypes()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id AS ID, name FROM payment_types ORDER BY id;", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewPaymentTypes.DataSource = ds.Tables[0];
                dataGridViewPaymentTypes.Columns["ID"].HeaderText = "Номер";
                dataGridViewPaymentTypes.Columns["name"].HeaderText = "Название";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadDepartmentProductTypeCombos()
        {
            LoadCombo(comboBoxLinkDepartment, "SELECT id, name FROM departments ORDER BY name;");
            LoadCombo(comboBoxLinkProductType, "SELECT id, name FROM product_types ORDER BY name;");
        }

        private void LoadCombo(ComboBox comboBox, string sql)
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataTable table = new DataTable();
                adapter.Fill(table);
                comboBox.DataSource = table;
                comboBox.DisplayMember = "name";
                comboBox.ValueMember = "id";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadDepartmentProductTypes()
        {
            try
            {
                string sql =
                    "SELECT department_product_types.id AS ID, departments.name AS department, " +
                    "product_types.name AS product_type, department_product_types.department_id, " +
                    "department_product_types.product_type_id " +
                    "FROM department_product_types " +
                    "JOIN departments ON department_product_types.department_id = departments.id " +
                    "JOIN product_types ON department_product_types.product_type_id = product_types.id " +
                    "ORDER BY departments.name, product_types.name;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewDepartmentProductTypes.DataSource = ds.Tables[0];
                dataGridViewDepartmentProductTypes.Columns["ID"].HeaderText = "Номер";
                dataGridViewDepartmentProductTypes.Columns["department"].HeaderText = "Отдел";
                dataGridViewDepartmentProductTypes.Columns["product_type"].HeaderText = "Вид товара";
                dataGridViewDepartmentProductTypes.Columns["department_id"].Visible = false;
                dataGridViewDepartmentProductTypes.Columns["product_type_id"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private int GetId(DataGridView grid)
        {
            if (grid.CurrentRow == null) return -1;
            return Convert.ToInt32(grid.CurrentRow.Cells["ID"].Value);
        }

        private void dataGridViewDepartments_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewDepartments.CurrentRow == null) return;
            textBoxDepartmentName.Text = Convert.ToString(dataGridViewDepartments.CurrentRow.Cells["name"].Value);
            textBoxDepartmentDescription.Text = Convert.ToString(dataGridViewDepartments.CurrentRow.Cells["description"].Value);
        }

        private void buttonAddDepartment_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO departments (name, description) VALUES (:name, :description);", con);
                cmd.Parameters.AddWithValue("name", textBoxDepartmentName.Text);
                cmd.Parameters.AddWithValue("description", textBoxDepartmentDescription.Text);
                cmd.ExecuteNonQuery();
                LoadDepartments();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonEditDepartment_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewDepartments);
            if (id == -1) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE departments SET name = :name, description = :description WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", textBoxDepartmentName.Text);
                cmd.Parameters.AddWithValue("description", textBoxDepartmentDescription.Text);
                cmd.ExecuteNonQuery();
                LoadDepartments();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDeleteDepartment_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewDepartments);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM departments WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadDepartments();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewProductTypes_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewProductTypes.CurrentRow == null) return;
            textBoxProductTypeName.Text = Convert.ToString(dataGridViewProductTypes.CurrentRow.Cells["name"].Value);
        }

        private void buttonAddProductType_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO product_types (name) VALUES (:name);", con);
                cmd.Parameters.AddWithValue("name", textBoxProductTypeName.Text);
                cmd.ExecuteNonQuery();
                LoadProductTypes();
                LoadProductTypesCombo();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonEditProductType_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewProductTypes);
            if (id == -1) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE product_types SET name = :name WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", textBoxProductTypeName.Text);
                cmd.ExecuteNonQuery();
                LoadProductTypes();
                LoadProductTypesCombo();
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDeleteProductType_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewProductTypes);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM product_types WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadProductTypes();
                LoadProductTypesCombo();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewProducts_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewProducts.CurrentRow == null) return;
            textBoxProductName.Text = Convert.ToString(dataGridViewProducts.CurrentRow.Cells["name"].Value);
            textBoxProductEd.Text = Convert.ToString(dataGridViewProducts.CurrentRow.Cells["ed"].Value);
            comboBoxProductType.SelectedValue = Convert.ToInt32(dataGridViewProducts.CurrentRow.Cells["product_type_id"].Value);
        }

        private void buttonAddProduct_Click(object sender, EventArgs e)
        {
            if (comboBoxProductType.SelectedValue == null) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO products (name, ed, product_type_id) VALUES (:name, :ed, :product_type_id);", con);
                cmd.Parameters.AddWithValue("name", textBoxProductName.Text);
                cmd.Parameters.AddWithValue("ed", textBoxProductEd.Text);
                cmd.Parameters.AddWithValue("product_type_id", Convert.ToInt32(comboBoxProductType.SelectedValue));
                cmd.ExecuteNonQuery();
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonEditProduct_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewProducts);
            if (id == -1 || comboBoxProductType.SelectedValue == null) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE products SET name = :name, ed = :ed, product_type_id = :product_type_id WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", textBoxProductName.Text);
                cmd.Parameters.AddWithValue("ed", textBoxProductEd.Text);
                cmd.Parameters.AddWithValue("product_type_id", Convert.ToInt32(comboBoxProductType.SelectedValue));
                cmd.ExecuteNonQuery();
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDeleteProduct_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewProducts);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM products WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewSuppliers_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewSuppliers.CurrentRow == null) return;
            textBoxSupplierName.Text = Convert.ToString(dataGridViewSuppliers.CurrentRow.Cells["name"].Value);
            textBoxSupplierAddress.Text = Convert.ToString(dataGridViewSuppliers.CurrentRow.Cells["address"].Value);
            textBoxSupplierPhone.Text = Convert.ToString(dataGridViewSuppliers.CurrentRow.Cells["phone"].Value);
        }

        private void buttonAddSupplier_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO suppliers (name, address, phone) VALUES (:name, :address, :phone);", con);
                cmd.Parameters.AddWithValue("name", textBoxSupplierName.Text);
                cmd.Parameters.AddWithValue("address", textBoxSupplierAddress.Text);
                cmd.Parameters.AddWithValue("phone", textBoxSupplierPhone.Text);
                cmd.ExecuteNonQuery();
                LoadSuppliers();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonEditSupplier_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewSuppliers);
            if (id == -1) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE suppliers SET name = :name, address = :address, phone = :phone WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", textBoxSupplierName.Text);
                cmd.Parameters.AddWithValue("address", textBoxSupplierAddress.Text);
                cmd.Parameters.AddWithValue("phone", textBoxSupplierPhone.Text);
                cmd.ExecuteNonQuery();
                LoadSuppliers();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDeleteSupplier_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewSuppliers);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM suppliers WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadSuppliers();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewPaymentTypes_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewPaymentTypes.CurrentRow == null) return;
            textBoxPaymentTypeName.Text = Convert.ToString(dataGridViewPaymentTypes.CurrentRow.Cells["name"].Value);
        }

        private void buttonAddPaymentType_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO payment_types (name) VALUES (:name);", con);
                cmd.Parameters.AddWithValue("name", textBoxPaymentTypeName.Text);
                cmd.ExecuteNonQuery();
                LoadPaymentTypes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonEditPaymentType_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewPaymentTypes);
            if (id == -1) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE payment_types SET name = :name WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", textBoxPaymentTypeName.Text);
                cmd.ExecuteNonQuery();
                LoadPaymentTypes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDeletePaymentType_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewPaymentTypes);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM payment_types WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadPaymentTypes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonAddDepartmentProductType_Click(object sender, EventArgs e)
        {
            if (comboBoxLinkDepartment.SelectedValue == null || comboBoxLinkProductType.SelectedValue == null) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand(
                    "INSERT INTO department_product_types (department_id, product_type_id) " +
                    "VALUES (:department_id, :product_type_id);", con);
                cmd.Parameters.AddWithValue("department_id", Convert.ToInt32(comboBoxLinkDepartment.SelectedValue));
                cmd.Parameters.AddWithValue("product_type_id", Convert.ToInt32(comboBoxLinkProductType.SelectedValue));
                cmd.ExecuteNonQuery();
                LoadDepartmentProductTypes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDeleteDepartmentProductType_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewDepartmentProductTypes);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM department_product_types WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadDepartmentProductTypes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonRefreshDepartments_Click(object sender, EventArgs e) { LoadDepartments(); }
        private void buttonRefreshProductTypes_Click(object sender, EventArgs e) { LoadProductTypes(); LoadProductTypesCombo(); }
        private void buttonRefreshProducts_Click(object sender, EventArgs e) { LoadProductTypesCombo(); LoadProducts(); }
        private void buttonRefreshSuppliers_Click(object sender, EventArgs e) { LoadSuppliers(); }
        private void buttonRefreshPaymentTypes_Click(object sender, EventArgs e) { LoadPaymentTypes(); }
        private void buttonRefreshDepartmentProductTypes_Click(object sender, EventArgs e) { LoadDepartmentProductTypeCombos(); LoadDepartmentProductTypes(); }
    }
}
