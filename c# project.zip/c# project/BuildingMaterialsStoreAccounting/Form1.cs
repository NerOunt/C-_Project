using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace BuildingMaterialsStoreAccounting
{
    public partial class Form1 : Form
    {
        public NpgsqlConnection con;

        public Form1()
        {
            InitializeComponent();
        }

        public void MyLoad()
        {
            this.StartPosition = FormStartPosition.CenterScreen;

            con = new NpgsqlConnection(
                "Server=localhost;Port=5432;User Id=postgres;Password=pass;Database=KravDatabase;"
            );

            con.Open();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                MyLoad();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (con != null && con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

        private void directoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDirectories f = new FormDirectories(con);
            f.ShowDialog();
        }

        private void documentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDocuments f = new FormDocuments(con);
            f.ShowDialog();
        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormReports f = new FormReports(con);
            f.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
