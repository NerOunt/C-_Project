using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BuildingMaterialsStoreAccounting")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("BuildingMaterialsStoreAccounting")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("80fb4d10-cab0-4a6d-925d-73f5ea6c0c7c")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
