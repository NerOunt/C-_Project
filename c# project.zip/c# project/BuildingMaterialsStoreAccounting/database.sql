DROP TABLE IF EXISTS sales_receipt_items CASCADE;
DROP TABLE IF EXISTS sales_receipts CASCADE;
DROP TABLE IF EXISTS incoming_invoice_items CASCADE;
DROP TABLE IF EXISTS incoming_invoices CASCADE;
DROP TABLE IF EXISTS products CASCADE;
DROP TABLE IF EXISTS department_product_types CASCADE;
DROP TABLE IF EXISTS payment_types CASCADE;
DROP TABLE IF EXISTS suppliers CASCADE;
DROP TABLE IF EXISTS product_types CASCADE;
DROP TABLE IF EXISTS departments CASCADE;

CREATE TABLE departments
(
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(200)
);

CREATE TABLE product_types
(
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE department_product_types
(
    id SERIAL PRIMARY KEY,
    department_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    product_type_id INTEGER NOT NULL REFERENCES product_types(id) ON DELETE CASCADE,
    UNIQUE (department_id, product_type_id)
);

CREATE TABLE products
(
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    ed VARCHAR(30) NOT NULL,
    product_type_id INTEGER NOT NULL REFERENCES product_types(id)
);

CREATE TABLE suppliers
(
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(200),
    phone VARCHAR(30)
);

CREATE TABLE payment_types
(
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL
);

CREATE TABLE incoming_invoices
(
    id SERIAL PRIMARY KEY,
    supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
    department_id INTEGER NOT NULL REFERENCES departments(id),
    invoice_date DATE NOT NULL,
    total_sum NUMERIC(12,2) NOT NULL DEFAULT 0
);

CREATE TABLE incoming_invoice_items
(
    id SERIAL PRIMARY KEY,
    incoming_invoice_id INTEGER NOT NULL REFERENCES incoming_invoices(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    quantity NUMERIC(12,3) NOT NULL,
    price NUMERIC(12,2) NOT NULL
);

CREATE TABLE sales_receipts
(
    id SERIAL PRIMARY KEY,
    department_id INTEGER NOT NULL REFERENCES departments(id),
    payment_type_id INTEGER NOT NULL REFERENCES payment_types(id),
    receipt_date DATE NOT NULL,
    total_sum NUMERIC(12,2) NOT NULL DEFAULT 0
);

CREATE TABLE sales_receipt_items
(
    id SERIAL PRIMARY KEY,
    sales_receipt_id INTEGER NOT NULL REFERENCES sales_receipts(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    quantity NUMERIC(12,3) NOT NULL,
    price NUMERIC(12,2) NOT NULL
);

CREATE OR REPLACE FUNCTION check_incoming_item_department()
RETURNS TRIGGER AS $$
DECLARE
    dep_id INTEGER;
    prod_type_id INTEGER;
BEGIN
    SELECT department_id
    INTO dep_id
    FROM incoming_invoices
    WHERE id = NEW.incoming_invoice_id;

    SELECT product_type_id
    INTO prod_type_id
    FROM products
    WHERE id = NEW.product_id;

    IF NOT EXISTS (
        SELECT 1
        FROM department_product_types
        WHERE department_id = dep_id
          AND product_type_id = prod_type_id
    ) THEN
        RAISE EXCEPTION 'Этот отдел не может принимать товар данного вида';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_check_incoming_item_department
BEFORE INSERT ON incoming_invoice_items
FOR EACH ROW
EXECUTE FUNCTION check_incoming_item_department();

CREATE OR REPLACE FUNCTION check_sales_item_department()
RETURNS TRIGGER AS $$
DECLARE
    dep_id INTEGER;
    prod_type_id INTEGER;
BEGIN
    SELECT department_id
    INTO dep_id
    FROM sales_receipts
    WHERE id = NEW.sales_receipt_id;

    SELECT product_type_id
    INTO prod_type_id
    FROM products
    WHERE id = NEW.product_id;

    IF NOT EXISTS (
        SELECT 1
        FROM department_product_types
        WHERE department_id = dep_id
          AND product_type_id = prod_type_id
    ) THEN
        RAISE EXCEPTION 'Этот отдел не может продавать товар данного вида';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_check_sales_item_department
BEFORE INSERT ON sales_receipt_items
FOR EACH ROW
EXECUTE FUNCTION check_sales_item_department();

CREATE OR REPLACE FUNCTION incoming_item_insert_sum()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE incoming_invoices
    SET total_sum = total_sum + NEW.quantity * NEW.price
    WHERE id = NEW.incoming_invoice_id;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_incoming_item_insert_sum
AFTER INSERT ON incoming_invoice_items
FOR EACH ROW
EXECUTE FUNCTION incoming_item_insert_sum();

CREATE OR REPLACE FUNCTION incoming_item_delete_sum()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE incoming_invoices
    SET total_sum = total_sum - OLD.quantity * OLD.price
    WHERE id = OLD.incoming_invoice_id;

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_incoming_item_delete_sum
AFTER DELETE ON incoming_invoice_items
FOR EACH ROW
EXECUTE FUNCTION incoming_item_delete_sum();

CREATE OR REPLACE FUNCTION sales_item_insert_sum()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE sales_receipts
    SET total_sum = total_sum + NEW.quantity * NEW.price
    WHERE id = NEW.sales_receipt_id;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_sales_item_insert_sum
AFTER INSERT ON sales_receipt_items
FOR EACH ROW
EXECUTE FUNCTION sales_item_insert_sum();

CREATE OR REPLACE FUNCTION sales_item_delete_sum()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE sales_receipts
    SET total_sum = total_sum - OLD.quantity * OLD.price
    WHERE id = OLD.sales_receipt_id;

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_sales_item_delete_sum
AFTER DELETE ON sales_receipt_items
FOR EACH ROW
EXECUTE FUNCTION sales_item_delete_sum();
