﻿using Npgsql;
using System.Data;

namespace WinFormsApp1
{
    public partial class FormReports : Form
    {
        private NpgsqlConnection con;

        private TabControl tabControl1;

        private DateTimePicker dateTimePickerFrom;
        private DateTimePicker dateTimePickerTo;
        private ComboBox comboBoxProductType;
        private DataGridView dataGridViewTurnover;

        private DateTimePicker dateTimePickerFrom2;
        private DateTimePicker dateTimePickerTo2;
        private DataGridView dataGridViewDepartmentReport;

        public FormReports()
        {
            InitializeComponent();
        }

        public FormReports(NpgsqlConnection con) : this()
        {
            this.con = con;
            Load += FormReports_Load;
        }

        private void BuildForm()
        {
            Text = "Отчёты";
            Width = 1150;
            Height = 650;
            StartPosition = FormStartPosition.CenterParent;

            tabControl1 = new TabControl();
            tabControl1.Dock = DockStyle.Fill;
            Controls.Add(tabControl1);

            BuildTurnoverTab();
            BuildDepartmentReportTab();
        }

        private void BuildTurnoverTab()
        {
            TabPage page = new TabPage("Обороты и остатки");
            Panel panel = CreateTopPanel();

            dateTimePickerFrom = AddDateTimePicker(panel, "С", 10, 10, 140);
            dateTimePickerTo = AddDateTimePicker(panel, "по", 170, 10, 140);
            comboBoxProductType = AddComboBox(panel, "Вид товара", 330, 10, 200);
            AddButton(panel, "Сформировать", 550, 35, 130, buttonCreateTurnoverReport_Click);
            AddButton(panel, "Excel", 700, 35, 90, buttonExcelTurnover_Click);

            dataGridViewTurnover = CreateGrid();
            page.Controls.Add(dataGridViewTurnover);
            page.Controls.Add(panel);
            tabControl1.TabPages.Add(page);
        }

        private void BuildDepartmentReportTab()
        {
            TabPage page = new TabPage("Отчёт по отделам");
            Panel panel = CreateTopPanel();

            dateTimePickerFrom2 = AddDateTimePicker(panel, "С", 10, 10, 140);
            dateTimePickerTo2 = AddDateTimePicker(panel, "по", 170, 10, 140);
            AddButton(panel, "Сформировать", 330, 35, 130, buttonCreateDepartmentReport_Click);
            AddButton(panel, "Excel", 480, 35, 90, buttonExcelDepartmentReport_Click);

            dataGridViewDepartmentReport = CreateGrid();
            page.Controls.Add(dataGridViewDepartmentReport);
            page.Controls.Add(panel);
            tabControl1.TabPages.Add(page);
        }

        private Panel CreateTopPanel()
        {
            Panel panel = new Panel();
            panel.Dock = DockStyle.Top;
            panel.Height = 75;
            return panel;
        }

        private DataGridView CreateGrid()
        {
            DataGridView grid = new DataGridView();
            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.AllowUserToAddRows = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            return grid;
        }

        private DateTimePicker AddDateTimePicker(Control parent, string text, int left, int top, int width)
        {
            Label label = new Label();
            label.Text = text;
            label.Left = left;
            label.Top = top;
            label.Width = width;
            parent.Controls.Add(label);

            DateTimePicker picker = new DateTimePicker();
            picker.Left = left;
            picker.Top = top + 25;
            picker.Width = width;
            parent.Controls.Add(picker);
            return picker;
        }

        private ComboBox AddComboBox(Control parent, string text, int left, int top, int width)
        {
            Label label = new Label();
            label.Text = text;
            label.Left = left;
            label.Top = top;
            label.Width = width;
            parent.Controls.Add(label);

            ComboBox comboBox = new ComboBox();
            comboBox.Left = left;
            comboBox.Top = top + 25;
            comboBox.Width = width;
            comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            parent.Controls.Add(comboBox);
            return comboBox;
        }

        private Button AddButton(Control parent, string text, int left, int top, int width, EventHandler click)
        {
            Button button = new Button();
            button.Text = text;
            button.Left = left;
            button.Top = top;
            button.Width = width;
            button.Height = 28;
            button.Click += click;
            parent.Controls.Add(button);
            return button;
        }

        private void FormReports_Load(object sender, EventArgs e)
        {
            LoadProductTypes();
        }

        private void LoadProductTypes()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id, name FROM product_types ORDER BY name;", con);
                DataTable table = new DataTable();
                adapter.Fill(table);
                comboBoxProductType.DataSource = table;
                comboBoxProductType.DisplayMember = "name";
                comboBoxProductType.ValueMember = "id";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private int GetSelectedProductTypeId()
        {
            if (comboBoxProductType.SelectedValue == null) return -1;
            if (comboBoxProductType.SelectedValue is DataRowView)
            {
                DataRowView row = (DataRowView)comboBoxProductType.SelectedValue;
                return Convert.ToInt32(row["id"]);
            }
            return Convert.ToInt32(comboBoxProductType.SelectedValue);
        }

        private void buttonCreateTurnoverReport_Click(object sender, EventArgs e)
        {
            int productTypeId = GetSelectedProductTypeId();
            if (productTypeId == -1) return;

            try
            {
                string sql =
                    "SELECT d.name AS department, pt.name AS product_type, p.name AS product, " +
                    "COALESCE((SELECT SUM(iii.quantity) FROM incoming_invoice_items iii " +
                    "JOIN incoming_invoices ii ON iii.incoming_invoice_id = ii.id " +
                    "WHERE ii.department_id = d.id AND iii.product_id = p.id AND ii.invoice_date < :date_from), 0) - " +
                    "COALESCE((SELECT SUM(sri.quantity) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "WHERE sr.department_id = d.id AND sri.product_id = p.id AND sr.receipt_date < :date_from), 0) AS start_balance, " +
                    "COALESCE((SELECT SUM(iii.quantity) FROM incoming_invoice_items iii " +
                    "JOIN incoming_invoices ii ON iii.incoming_invoice_id = ii.id " +
                    "WHERE ii.department_id = d.id AND iii.product_id = p.id AND ii.invoice_date BETWEEN :date_from AND :date_to), 0) AS incoming_quantity, " +
                    "COALESCE((SELECT SUM(sri.quantity) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "WHERE sr.department_id = d.id AND sri.product_id = p.id AND sr.receipt_date BETWEEN :date_from AND :date_to), 0) AS sales_quantity, " +
                    "COALESCE((SELECT SUM(iii.quantity * iii.price) FROM incoming_invoice_items iii " +
                    "JOIN incoming_invoices ii ON iii.incoming_invoice_id = ii.id " +
                    "WHERE ii.department_id = d.id AND iii.product_id = p.id AND ii.invoice_date BETWEEN :date_from AND :date_to), 0) AS incoming_sum, " +
                    "COALESCE((SELECT SUM(sri.quantity * sri.price) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "WHERE sr.department_id = d.id AND sri.product_id = p.id AND sr.receipt_date BETWEEN :date_from AND :date_to), 0) AS sales_sum " +
                    "FROM department_product_types dpt " +
                    "JOIN departments d ON dpt.department_id = d.id " +
                    "JOIN product_types pt ON dpt.product_type_id = pt.id " +
                    "JOIN products p ON p.product_type_id = pt.id " +
                    "WHERE dpt.product_type_id = :product_type_id " +
                    "ORDER BY d.name, p.name;";

                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                adapter.SelectCommand.Parameters.AddWithValue("date_from", dateTimePickerFrom.Value.Date);
                adapter.SelectCommand.Parameters.AddWithValue("date_to", dateTimePickerTo.Value.Date);
                adapter.SelectCommand.Parameters.AddWithValue("product_type_id", productTypeId);

                DataTable table = new DataTable();
                adapter.Fill(table);
                table.Columns.Add("end_balance", typeof(decimal));

                foreach (DataRow row in table.Rows)
                {
                    decimal startBalance = Convert.ToDecimal(row["start_balance"]);
                    decimal incomingQuantity = Convert.ToDecimal(row["incoming_quantity"]);
                    decimal salesQuantity = Convert.ToDecimal(row["sales_quantity"]);
                    row["end_balance"] = startBalance + incomingQuantity - salesQuantity;
                }

                dataGridViewTurnover.DataSource = table;
                dataGridViewTurnover.Columns["department"].HeaderText = "Отдел";
                dataGridViewTurnover.Columns["product_type"].HeaderText = "Вид товара";
                dataGridViewTurnover.Columns["product"].HeaderText = "Товар";
                dataGridViewTurnover.Columns["start_balance"].HeaderText = "Начальный остаток";
                dataGridViewTurnover.Columns["incoming_quantity"].HeaderText = "Приход за период";
                dataGridViewTurnover.Columns["sales_quantity"].HeaderText = "Расход за период";
                dataGridViewTurnover.Columns["incoming_sum"].HeaderText = "Сумма прихода";
                dataGridViewTurnover.Columns["sales_sum"].HeaderText = "Сумма продаж";
                dataGridViewTurnover.Columns["end_balance"].HeaderText = "Конечный остаток";

                dataGridViewTurnover.Columns["start_balance"].DefaultCellStyle.Format = "0.###";
                dataGridViewTurnover.Columns["incoming_quantity"].DefaultCellStyle.Format = "0.###";
                dataGridViewTurnover.Columns["sales_quantity"].DefaultCellStyle.Format = "0.###";
                dataGridViewTurnover.Columns["end_balance"].DefaultCellStyle.Format = "0.###";
                dataGridViewTurnover.Columns["incoming_sum"].DefaultCellStyle.Format = "0.00";
                dataGridViewTurnover.Columns["sales_sum"].DefaultCellStyle.Format = "0.00";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonCreateDepartmentReport_Click(object sender, EventArgs e)
        {
            try
            {
                string sql =
                    "SELECT d.name AS department, " +
                    "COALESCE((SELECT SUM(iii.quantity * iii.price) FROM incoming_invoice_items iii " +
                    "JOIN incoming_invoices ii ON iii.incoming_invoice_id = ii.id " +
                    "WHERE ii.department_id = d.id AND ii.invoice_date BETWEEN :date_from AND :date_to), 0) AS incoming_sum, " +
                    "COALESCE((SELECT SUM(sri.quantity * sri.price) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "WHERE sr.department_id = d.id AND sr.receipt_date BETWEEN :date_from AND :date_to), 0) AS sales_sum, " +
                    "COALESCE((SELECT SUM(sri.quantity * sri.price) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "JOIN payment_types pt ON sr.payment_type_id = pt.id " +
                    "WHERE sr.department_id = d.id AND sr.receipt_date BETWEEN :date_from AND :date_to AND pt.name = 'Наличные'), 0) AS cash_sum, " +
                    "COALESCE((SELECT SUM(sri.quantity * sri.price) FROM sales_receipt_items sri " +
                    "JOIN sales_receipts sr ON sri.sales_receipt_id = sr.id " +
                    "JOIN payment_types pt ON sr.payment_type_id = pt.id " +
                    "WHERE sr.department_id = d.id AND sr.receipt_date BETWEEN :date_from AND :date_to AND pt.name = 'Карта'), 0) AS card_sum " +
                    "FROM departments d ORDER BY d.name;";

                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                adapter.SelectCommand.Parameters.AddWithValue("date_from", dateTimePickerFrom2.Value.Date);
                adapter.SelectCommand.Parameters.AddWithValue("date_to", dateTimePickerTo2.Value.Date);

                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridViewDepartmentReport.DataSource = table;
                dataGridViewDepartmentReport.Columns["department"].HeaderText = "Отдел";
                dataGridViewDepartmentReport.Columns["incoming_sum"].HeaderText = "Сумма полученных товаров";
                dataGridViewDepartmentReport.Columns["sales_sum"].HeaderText = "Сумма продаж всего";
                dataGridViewDepartmentReport.Columns["cash_sum"].HeaderText = "Продажи наличными";
                dataGridViewDepartmentReport.Columns["card_sum"].HeaderText = "Продажи по карте";

                dataGridViewDepartmentReport.Columns["incoming_sum"].DefaultCellStyle.Format = "0.00";
                dataGridViewDepartmentReport.Columns["sales_sum"].DefaultCellStyle.Format = "0.00";
                dataGridViewDepartmentReport.Columns["cash_sum"].DefaultCellStyle.Format = "0.00";
                dataGridViewDepartmentReport.Columns["card_sum"].DefaultCellStyle.Format = "0.00";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonExcelTurnover_Click(object sender, EventArgs e)
        {
            ExportToExcel(dataGridViewTurnover, "Обороты и остатки", dateTimePickerFrom.Value, dateTimePickerTo.Value);
        }

        private void buttonExcelDepartmentReport_Click(object sender, EventArgs e)
        {
            ExportToExcel(dataGridViewDepartmentReport, "Отчёт по отделам", dateTimePickerFrom2.Value, dateTimePickerTo2.Value);
        }

        private void ExportToExcel(DataGridView grid, string title, DateTime dateFrom, DateTime dateTo)
        {
            try
            {
                if (grid.DataSource == null)
                {
                    MessageBox.Show("Сначала сформируйте отчёт.");
                    return;
                }

                Type excelType = Type.GetTypeFromProgID("Excel.Application");
                if (excelType == null)
                {
                    MessageBox.Show("Microsoft Excel не установлен на этом компьютере.");
                    return;
                }

                dynamic excelApp = Activator.CreateInstance(excelType);
                excelApp.Visible = true;
                dynamic workbook = excelApp.Workbooks.Add();
                dynamic worksheet = workbook.Worksheets[1];

                worksheet.Cells[1, 1] = title;
                worksheet.Cells[2, 1] = "Период: " + dateFrom.ToShortDateString() + " - " + dateTo.ToShortDateString();

                for (int j = 0; j < grid.Columns.Count; j++)
                {
                    worksheet.Cells[4, j + 1] = grid.Columns[j].HeaderText;
                }

                for (int i = 0; i < grid.Rows.Count; i++)
                {
                    if (grid.Rows[i].IsNewRow) continue;
                    for (int j = 0; j < grid.Columns.Count; j++)
                    {
                        object value = grid.Rows[i].Cells[j].Value;

                        if (value == null || value == DBNull.Value)
                        {
                            worksheet.Cells[i + 5, j + 1] = "";
                        }
                        else if (value is decimal || value is double || value is float || value is int || value is long)
                        {
                            if (grid.Columns[j].DefaultCellStyle.Format == "0.00")
                            {
                                worksheet.Cells[i + 5, j + 1] = Math.Round(Convert.ToDouble(value), 2);
                            }
                            else if (grid.Columns[j].DefaultCellStyle.Format == "0.###")
                            {
                                worksheet.Cells[i + 5, j + 1] = Math.Round(Convert.ToDouble(value), 3);
                            }
                            else
                            {
                                worksheet.Cells[i + 5, j + 1] = Convert.ToDouble(value);
                            }
                        }
                        else
                        {
                            worksheet.Cells[i + 5, j + 1] = Convert.ToString(value);
                        }
                    }
                }

                worksheet.Columns.AutoFit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

