﻿namespace WinFormsApp1
{
    partial class FormDocuments
    {
        private System.ComponentModel.IContainer components = null;
        private Panel panelIncoming;
        private Panel panelSales;
        private SplitContainer splitContainerIncoming;
        private SplitContainer splitContainerSales;
        private Label labelIncomingDate;
        private Label labelIncomingSupplier;
        private Label labelIncomingDepartment;
        private Label labelIncomingProduct;
        private Label labelIncomingQuantity;
        private Label labelIncomingPrice;
        private Label labelSalesDate;
        private Label labelSalesDepartment;
        private Label labelSalesPaymentType;
        private Label labelSalesProduct;
        private Label labelSalesQuantity;
        private Label labelSalesPrice;
        private Button buttonAddIncomingInvoice;
        private Button buttonDeleteIncomingInvoice;
        private Button buttonRefreshIncoming;
        private Button buttonAddIncomingItem;
        private Button buttonDeleteIncomingItem;
        private Button buttonAddSalesReceipt;
        private Button buttonDeleteSalesReceipt;
        private Button buttonRefreshSales;
        private Button buttonAddSalesItem;
        private Button buttonDeleteSalesItem;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            TabPage tabPageIncoming = new TabPage();
            TabPage tabPageSales = new TabPage();
            panelIncoming = new Panel();
            labelIncomingDate = new Label();
            dateTimePickerIncomingDate = new DateTimePicker();
            labelIncomingSupplier = new Label();
            comboBoxIncomingSupplier = new ComboBox();
            labelIncomingDepartment = new Label();
            comboBoxIncomingDepartment = new ComboBox();
            buttonAddIncomingInvoice = new Button();
            buttonDeleteIncomingInvoice = new Button();
            buttonRefreshIncoming = new Button();
            labelIncomingProduct = new Label();
            comboBoxIncomingProduct = new ComboBox();
            labelIncomingQuantity = new Label();
            textBoxIncomingQuantity = new TextBox();
            labelIncomingPrice = new Label();
            textBoxIncomingPrice = new TextBox();
            buttonAddIncomingItem = new Button();
            buttonDeleteIncomingItem = new Button();
            splitContainerIncoming = new SplitContainer();
            dataGridViewIncomingInvoices = new DataGridView();
            dataGridViewIncomingItems = new DataGridView();
            panelSales = new Panel();
            labelSalesDate = new Label();
            dateTimePickerSalesDate = new DateTimePicker();
            labelSalesDepartment = new Label();
            comboBoxSalesDepartment = new ComboBox();
            labelSalesPaymentType = new Label();
            comboBoxSalesPaymentType = new ComboBox();
            buttonAddSalesReceipt = new Button();
            buttonDeleteSalesReceipt = new Button();
            buttonRefreshSales = new Button();
            labelSalesProduct = new Label();
            comboBoxSalesProduct = new ComboBox();
            labelSalesQuantity = new Label();
            textBoxSalesQuantity = new TextBox();
            labelSalesPrice = new Label();
            textBoxSalesPrice = new TextBox();
            buttonAddSalesItem = new Button();
            buttonDeleteSalesItem = new Button();
            splitContainerSales = new SplitContainer();
            dataGridViewSalesReceipts = new DataGridView();
            dataGridViewSalesItems = new DataGridView();
            tabControl1.SuspendLayout();
            tabPageIncoming.SuspendLayout();
            tabPageSales.SuspendLayout();
            panelIncoming.SuspendLayout();
            panelSales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainerIncoming).BeginInit();
            splitContainerIncoming.Panel1.SuspendLayout();
            splitContainerIncoming.Panel2.SuspendLayout();
            splitContainerIncoming.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainerSales).BeginInit();
            splitContainerSales.Panel1.SuspendLayout();
            splitContainerSales.Panel2.SuspendLayout();
            splitContainerSales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewIncomingInvoices).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewIncomingItems).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSalesReceipts).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSalesItems).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPageIncoming);
            tabControl1.Controls.Add(tabPageSales);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1184, 681);
            tabControl1.TabIndex = 0;
            // 
            // tabPageIncoming
            // 
            tabPageIncoming.Controls.Add(splitContainerIncoming);
            tabPageIncoming.Controls.Add(panelIncoming);
            tabPageIncoming.Location = new Point(4, 24);
            tabPageIncoming.Name = "tabPageIncoming";
            tabPageIncoming.Padding = new Padding(3);
            tabPageIncoming.Size = new Size(1176, 653);
            tabPageIncoming.TabIndex = 0;
            tabPageIncoming.Text = "Приходные накладные";
            tabPageIncoming.UseVisualStyleBackColor = true;
            // 
            // panelIncoming
            // 
            panelIncoming.Controls.Add(labelIncomingDate);
            panelIncoming.Controls.Add(dateTimePickerIncomingDate);
            panelIncoming.Controls.Add(labelIncomingSupplier);
            panelIncoming.Controls.Add(comboBoxIncomingSupplier);
            panelIncoming.Controls.Add(labelIncomingDepartment);
            panelIncoming.Controls.Add(comboBoxIncomingDepartment);
            panelIncoming.Controls.Add(buttonAddIncomingInvoice);
            panelIncoming.Controls.Add(buttonDeleteIncomingInvoice);
            panelIncoming.Controls.Add(buttonRefreshIncoming);
            panelIncoming.Controls.Add(labelIncomingProduct);
            panelIncoming.Controls.Add(comboBoxIncomingProduct);
            panelIncoming.Controls.Add(labelIncomingQuantity);
            panelIncoming.Controls.Add(textBoxIncomingQuantity);
            panelIncoming.Controls.Add(labelIncomingPrice);
            panelIncoming.Controls.Add(textBoxIncomingPrice);
            panelIncoming.Controls.Add(buttonAddIncomingItem);
            panelIncoming.Controls.Add(buttonDeleteIncomingItem);
            panelIncoming.Dock = DockStyle.Top;
            panelIncoming.Location = new Point(3, 3);
            panelIncoming.Name = "panelIncoming";
            panelIncoming.Size = new Size(1170, 120);
            panelIncoming.TabIndex = 0;
            // 
            // incoming controls
            // 
            labelIncomingDate.AutoSize = true;
            labelIncomingDate.Location = new Point(10, 10);
            labelIncomingDate.Text = "Дата";
            dateTimePickerIncomingDate.Location = new Point(10, 35);
            dateTimePickerIncomingDate.Size = new Size(140, 23);
            labelIncomingSupplier.AutoSize = true;
            labelIncomingSupplier.Location = new Point(170, 10);
            labelIncomingSupplier.Text = "Поставщик";
            comboBoxIncomingSupplier.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxIncomingSupplier.Location = new Point(170, 35);
            comboBoxIncomingSupplier.Size = new Size(180, 23);
            labelIncomingDepartment.AutoSize = true;
            labelIncomingDepartment.Location = new Point(370, 10);
            labelIncomingDepartment.Text = "Отдел";
            comboBoxIncomingDepartment.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxIncomingDepartment.Location = new Point(370, 35);
            comboBoxIncomingDepartment.Size = new Size(180, 23);
            comboBoxIncomingDepartment.SelectedIndexChanged += comboBoxIncomingDepartment_SelectedIndexChanged;
            buttonAddIncomingInvoice.Location = new Point(570, 33);
            buttonAddIncomingInvoice.Size = new Size(145, 27);
            buttonAddIncomingInvoice.Text = "Добавить накладную";
            buttonAddIncomingInvoice.Click += buttonAddIncomingInvoice_Click;
            buttonDeleteIncomingInvoice.Location = new Point(725, 33);
            buttonDeleteIncomingInvoice.Size = new Size(135, 27);
            buttonDeleteIncomingInvoice.Text = "Удалить накладную";
            buttonDeleteIncomingInvoice.Click += buttonDeleteIncomingInvoice_Click;
            buttonRefreshIncoming.Location = new Point(870, 33);
            buttonRefreshIncoming.Size = new Size(90, 27);
            buttonRefreshIncoming.Text = "Обновить";
            buttonRefreshIncoming.Click += buttonRefreshIncoming_Click;
            labelIncomingProduct.AutoSize = true;
            labelIncomingProduct.Location = new Point(10, 68);
            labelIncomingProduct.Text = "Товар";
            comboBoxIncomingProduct.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxIncomingProduct.Location = new Point(10, 92);
            comboBoxIncomingProduct.Size = new Size(220, 23);
            labelIncomingQuantity.AutoSize = true;
            labelIncomingQuantity.Location = new Point(250, 68);
            labelIncomingQuantity.Text = "Количество";
            textBoxIncomingQuantity.Location = new Point(250, 92);
            textBoxIncomingQuantity.Size = new Size(100, 23);
            labelIncomingPrice.AutoSize = true;
            labelIncomingPrice.Location = new Point(370, 68);
            labelIncomingPrice.Text = "Цена";
            textBoxIncomingPrice.Location = new Point(370, 92);
            textBoxIncomingPrice.Size = new Size(100, 23);
            buttonAddIncomingItem.Location = new Point(490, 90);
            buttonAddIncomingItem.Size = new Size(120, 27);
            buttonAddIncomingItem.Text = "Добавить товар";
            buttonAddIncomingItem.Click += buttonAddIncomingItem_Click;
            buttonDeleteIncomingItem.Location = new Point(620, 90);
            buttonDeleteIncomingItem.Size = new Size(110, 27);
            buttonDeleteIncomingItem.Text = "Удалить товар";
            buttonDeleteIncomingItem.Click += buttonDeleteIncomingItem_Click;
            // 
            // splitContainerIncoming
            // 
            splitContainerIncoming.Dock = DockStyle.Fill;
            splitContainerIncoming.Location = new Point(3, 123);
            splitContainerIncoming.Name = "splitContainerIncoming";
            splitContainerIncoming.Orientation = Orientation.Horizontal;
            splitContainerIncoming.Panel1.Controls.Add(dataGridViewIncomingInvoices);
            splitContainerIncoming.Panel2.Controls.Add(dataGridViewIncomingItems);
            splitContainerIncoming.Size = new Size(1170, 527);
            splitContainerIncoming.SplitterDistance = 255;
            splitContainerIncoming.TabIndex = 1;
            // 
            // dataGridViewIncomingInvoices
            // 
            dataGridViewIncomingInvoices.AllowUserToAddRows = false;
            dataGridViewIncomingInvoices.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewIncomingInvoices.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewIncomingInvoices.Dock = DockStyle.Fill;
            dataGridViewIncomingInvoices.MultiSelect = false;
            dataGridViewIncomingInvoices.Name = "dataGridViewIncomingInvoices";
            dataGridViewIncomingInvoices.ReadOnly = true;
            dataGridViewIncomingInvoices.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewIncomingInvoices.SelectionChanged += dataGridViewIncomingInvoices_SelectionChanged;
            // 
            // dataGridViewIncomingItems
            // 
            dataGridViewIncomingItems.AllowUserToAddRows = false;
            dataGridViewIncomingItems.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewIncomingItems.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewIncomingItems.Dock = DockStyle.Fill;
            dataGridViewIncomingItems.MultiSelect = false;
            dataGridViewIncomingItems.Name = "dataGridViewIncomingItems";
            dataGridViewIncomingItems.ReadOnly = true;
            dataGridViewIncomingItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            // 
            // tabPageSales
            // 
            tabPageSales.Controls.Add(splitContainerSales);
            tabPageSales.Controls.Add(panelSales);
            tabPageSales.Location = new Point(4, 24);
            tabPageSales.Name = "tabPageSales";
            tabPageSales.Padding = new Padding(3);
            tabPageSales.Size = new Size(1176, 653);
            tabPageSales.TabIndex = 1;
            tabPageSales.Text = "Продажи";
            tabPageSales.UseVisualStyleBackColor = true;
            // 
            // panelSales
            // 
            panelSales.Controls.Add(labelSalesDate);
            panelSales.Controls.Add(dateTimePickerSalesDate);
            panelSales.Controls.Add(labelSalesDepartment);
            panelSales.Controls.Add(comboBoxSalesDepartment);
            panelSales.Controls.Add(labelSalesPaymentType);
            panelSales.Controls.Add(comboBoxSalesPaymentType);
            panelSales.Controls.Add(buttonAddSalesReceipt);
            panelSales.Controls.Add(buttonDeleteSalesReceipt);
            panelSales.Controls.Add(buttonRefreshSales);
            panelSales.Controls.Add(labelSalesProduct);
            panelSales.Controls.Add(comboBoxSalesProduct);
            panelSales.Controls.Add(labelSalesQuantity);
            panelSales.Controls.Add(textBoxSalesQuantity);
            panelSales.Controls.Add(labelSalesPrice);
            panelSales.Controls.Add(textBoxSalesPrice);
            panelSales.Controls.Add(buttonAddSalesItem);
            panelSales.Controls.Add(buttonDeleteSalesItem);
            panelSales.Dock = DockStyle.Top;
            panelSales.Location = new Point(3, 3);
            panelSales.Name = "panelSales";
            panelSales.Size = new Size(1170, 120);
            panelSales.TabIndex = 0;
            // 
            // sales controls
            // 
            labelSalesDate.AutoSize = true;
            labelSalesDate.Location = new Point(10, 10);
            labelSalesDate.Text = "Дата";
            dateTimePickerSalesDate.Location = new Point(10, 35);
            dateTimePickerSalesDate.Size = new Size(140, 23);
            labelSalesDepartment.AutoSize = true;
            labelSalesDepartment.Location = new Point(170, 10);
            labelSalesDepartment.Text = "Отдел";
            comboBoxSalesDepartment.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxSalesDepartment.Location = new Point(170, 35);
            comboBoxSalesDepartment.Size = new Size(180, 23);
            comboBoxSalesDepartment.SelectedIndexChanged += comboBoxSalesDepartment_SelectedIndexChanged;
            labelSalesPaymentType.AutoSize = true;
            labelSalesPaymentType.Location = new Point(370, 10);
            labelSalesPaymentType.Text = "Тип оплаты";
            comboBoxSalesPaymentType.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxSalesPaymentType.Location = new Point(370, 35);
            comboBoxSalesPaymentType.Size = new Size(180, 23);
            buttonAddSalesReceipt.Location = new Point(570, 33);
            buttonAddSalesReceipt.Size = new Size(110, 27);
            buttonAddSalesReceipt.Text = "Добавить чек";
            buttonAddSalesReceipt.Click += buttonAddSalesReceipt_Click;
            buttonDeleteSalesReceipt.Location = new Point(690, 33);
            buttonDeleteSalesReceipt.Size = new Size(105, 27);
            buttonDeleteSalesReceipt.Text = "Удалить чек";
            buttonDeleteSalesReceipt.Click += buttonDeleteSalesReceipt_Click;
            buttonRefreshSales.Location = new Point(805, 33);
            buttonRefreshSales.Size = new Size(90, 27);
            buttonRefreshSales.Text = "Обновить";
            buttonRefreshSales.Click += buttonRefreshSales_Click;
            labelSalesProduct.AutoSize = true;
            labelSalesProduct.Location = new Point(10, 68);
            labelSalesProduct.Text = "Товар";
            comboBoxSalesProduct.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxSalesProduct.Location = new Point(10, 92);
            comboBoxSalesProduct.Size = new Size(220, 23);
            labelSalesQuantity.AutoSize = true;
            labelSalesQuantity.Location = new Point(250, 68);
            labelSalesQuantity.Text = "Количество";
            textBoxSalesQuantity.Location = new Point(250, 92);
            textBoxSalesQuantity.Size = new Size(100, 23);
            labelSalesPrice.AutoSize = true;
            labelSalesPrice.Location = new Point(370, 68);
            labelSalesPrice.Text = "Цена";
            textBoxSalesPrice.Location = new Point(370, 92);
            textBoxSalesPrice.Size = new Size(100, 23);
            buttonAddSalesItem.Location = new Point(490, 90);
            buttonAddSalesItem.Size = new Size(120, 27);
            buttonAddSalesItem.Text = "Добавить товар";
            buttonAddSalesItem.Click += buttonAddSalesItem_Click;
            buttonDeleteSalesItem.Location = new Point(620, 90);
            buttonDeleteSalesItem.Size = new Size(110, 27);
            buttonDeleteSalesItem.Text = "Удалить товар";
            buttonDeleteSalesItem.Click += buttonDeleteSalesItem_Click;
            // 
            // splitContainerSales
            // 
            splitContainerSales.Dock = DockStyle.Fill;
            splitContainerSales.Location = new Point(3, 123);
            splitContainerSales.Name = "splitContainerSales";
            splitContainerSales.Orientation = Orientation.Horizontal;
            splitContainerSales.Panel1.Controls.Add(dataGridViewSalesReceipts);
            splitContainerSales.Panel2.Controls.Add(dataGridViewSalesItems);
            splitContainerSales.Size = new Size(1170, 527);
            splitContainerSales.SplitterDistance = 255;
            splitContainerSales.TabIndex = 1;
            // 
            // dataGridViewSalesReceipts
            // 
            dataGridViewSalesReceipts.AllowUserToAddRows = false;
            dataGridViewSalesReceipts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewSalesReceipts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewSalesReceipts.Dock = DockStyle.Fill;
            dataGridViewSalesReceipts.MultiSelect = false;
            dataGridViewSalesReceipts.Name = "dataGridViewSalesReceipts";
            dataGridViewSalesReceipts.ReadOnly = true;
            dataGridViewSalesReceipts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewSalesReceipts.SelectionChanged += dataGridViewSalesReceipts_SelectionChanged;
            // 
            // dataGridViewSalesItems
            // 
            dataGridViewSalesItems.AllowUserToAddRows = false;
            dataGridViewSalesItems.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewSalesItems.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewSalesItems.Dock = DockStyle.Fill;
            dataGridViewSalesItems.MultiSelect = false;
            dataGridViewSalesItems.Name = "dataGridViewSalesItems";
            dataGridViewSalesItems.ReadOnly = true;
            dataGridViewSalesItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            // 
            // FormDocuments
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1184, 681);
            Controls.Add(tabControl1);
            Name = "FormDocuments";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Документы";
            tabControl1.ResumeLayout(false);
            tabPageIncoming.ResumeLayout(false);
            tabPageSales.ResumeLayout(false);
            panelIncoming.ResumeLayout(false);
            panelIncoming.PerformLayout();
            panelSales.ResumeLayout(false);
            panelSales.PerformLayout();
            splitContainerIncoming.Panel1.ResumeLayout(false);
            splitContainerIncoming.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainerIncoming).EndInit();
            splitContainerIncoming.ResumeLayout(false);
            splitContainerSales.Panel1.ResumeLayout(false);
            splitContainerSales.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainerSales).EndInit();
            splitContainerSales.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewIncomingInvoices).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewIncomingItems).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSalesReceipts).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSalesItems).EndInit();
            ResumeLayout(false);
        }
    }
}

