﻿namespace WinFormsApp1
{
    partial class FormReports
    {
        private System.ComponentModel.IContainer components = null;
        private Panel panelTurnover;
        private Panel panelDepartmentReport;
        private Label labelDateFrom;
        private Label labelDateTo;
        private Label labelProductType;
        private Label labelDateFrom2;
        private Label labelDateTo2;
        private Button buttonCreateTurnoverReport;
        private Button buttonExcelTurnover;
        private Button buttonCreateDepartmentReport;
        private Button buttonExcelDepartmentReport;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            panelTurnover = new Panel();
            labelDateFrom = new Label();
            dateTimePickerFrom = new DateTimePicker();
            labelDateTo = new Label();
            dateTimePickerTo = new DateTimePicker();
            labelProductType = new Label();
            comboBoxProductType = new ComboBox();
            buttonCreateTurnoverReport = new Button();
            buttonExcelTurnover = new Button();
            dataGridViewTurnover = new DataGridView();
            panelDepartmentReport = new Panel();
            labelDateFrom2 = new Label();
            dateTimePickerFrom2 = new DateTimePicker();
            labelDateTo2 = new Label();
            dateTimePickerTo2 = new DateTimePicker();
            buttonCreateDepartmentReport = new Button();
            buttonExcelDepartmentReport = new Button();
            dataGridViewDepartmentReport = new DataGridView();
            TabPage tabPageTurnover = new TabPage();
            TabPage tabPageDepartmentReport = new TabPage();
            tabControl1.SuspendLayout();
            tabPageTurnover.SuspendLayout();
            tabPageDepartmentReport.SuspendLayout();
            panelTurnover.SuspendLayout();
            panelDepartmentReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTurnover).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewDepartmentReport).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPageTurnover);
            tabControl1.Controls.Add(tabPageDepartmentReport);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1134, 611);
            tabControl1.TabIndex = 0;
            // 
            // tabPageTurnover
            // 
            tabPageTurnover.Controls.Add(dataGridViewTurnover);
            tabPageTurnover.Controls.Add(panelTurnover);
            tabPageTurnover.Location = new Point(4, 24);
            tabPageTurnover.Name = "tabPageTurnover";
            tabPageTurnover.Padding = new Padding(3);
            tabPageTurnover.Size = new Size(1126, 583);
            tabPageTurnover.TabIndex = 0;
            tabPageTurnover.Text = "Обороты и остатки";
            tabPageTurnover.UseVisualStyleBackColor = true;
            // 
            // panelTurnover
            // 
            panelTurnover.Controls.Add(labelDateFrom);
            panelTurnover.Controls.Add(dateTimePickerFrom);
            panelTurnover.Controls.Add(labelDateTo);
            panelTurnover.Controls.Add(dateTimePickerTo);
            panelTurnover.Controls.Add(labelProductType);
            panelTurnover.Controls.Add(comboBoxProductType);
            panelTurnover.Controls.Add(buttonCreateTurnoverReport);
            panelTurnover.Controls.Add(buttonExcelTurnover);
            panelTurnover.Dock = DockStyle.Top;
            panelTurnover.Location = new Point(3, 3);
            panelTurnover.Name = "panelTurnover";
            panelTurnover.Size = new Size(1120, 75);
            panelTurnover.TabIndex = 0;
            // 
            // labelDateFrom
            // 
            labelDateFrom.AutoSize = true;
            labelDateFrom.Location = new Point(10, 12);
            labelDateFrom.Name = "labelDateFrom";
            labelDateFrom.Size = new Size(74, 15);
            labelDateFrom.TabIndex = 0;
            labelDateFrom.Text = "Дата начала";
            // 
            // dateTimePickerFrom
            // 
            dateTimePickerFrom.Location = new Point(10, 38);
            dateTimePickerFrom.Name = "dateTimePickerFrom";
            dateTimePickerFrom.Size = new Size(145, 23);
            dateTimePickerFrom.TabIndex = 1;
            // 
            // labelDateTo
            // 
            labelDateTo.AutoSize = true;
            labelDateTo.Location = new Point(175, 12);
            labelDateTo.Name = "labelDateTo";
            labelDateTo.Size = new Size(69, 15);
            labelDateTo.TabIndex = 2;
            labelDateTo.Text = "Дата конца";
            // 
            // dateTimePickerTo
            // 
            dateTimePickerTo.Location = new Point(175, 38);
            dateTimePickerTo.Name = "dateTimePickerTo";
            dateTimePickerTo.Size = new Size(145, 23);
            dateTimePickerTo.TabIndex = 3;
            // 
            // labelProductType
            // 
            labelProductType.AutoSize = true;
            labelProductType.Location = new Point(340, 12);
            labelProductType.Name = "labelProductType";
            labelProductType.Size = new Size(68, 15);
            labelProductType.TabIndex = 4;
            labelProductType.Text = "Вид товара";
            // 
            // comboBoxProductType
            // 
            comboBoxProductType.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxProductType.Location = new Point(340, 38);
            comboBoxProductType.Name = "comboBoxProductType";
            comboBoxProductType.Size = new Size(210, 23);
            comboBoxProductType.TabIndex = 5;
            // 
            // buttonCreateTurnoverReport
            // 
            buttonCreateTurnoverReport.Location = new Point(575, 36);
            buttonCreateTurnoverReport.Name = "buttonCreateTurnoverReport";
            buttonCreateTurnoverReport.Size = new Size(130, 27);
            buttonCreateTurnoverReport.TabIndex = 6;
            buttonCreateTurnoverReport.Text = "Сформировать";
            buttonCreateTurnoverReport.UseVisualStyleBackColor = true;
            buttonCreateTurnoverReport.Click += buttonCreateTurnoverReport_Click;
            // 
            // buttonExcelTurnover
            // 
            buttonExcelTurnover.Location = new Point(720, 36);
            buttonExcelTurnover.Name = "buttonExcelTurnover";
            buttonExcelTurnover.Size = new Size(90, 27);
            buttonExcelTurnover.TabIndex = 7;
            buttonExcelTurnover.Text = "Excel";
            buttonExcelTurnover.UseVisualStyleBackColor = true;
            buttonExcelTurnover.Click += buttonExcelTurnover_Click;
            // 
            // dataGridViewTurnover
            // 
            dataGridViewTurnover.AllowUserToAddRows = false;
            dataGridViewTurnover.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewTurnover.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewTurnover.Dock = DockStyle.Fill;
            dataGridViewTurnover.Location = new Point(3, 78);
            dataGridViewTurnover.MultiSelect = false;
            dataGridViewTurnover.Name = "dataGridViewTurnover";
            dataGridViewTurnover.ReadOnly = true;
            dataGridViewTurnover.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewTurnover.Size = new Size(1120, 502);
            dataGridViewTurnover.TabIndex = 1;
            // 
            // tabPageDepartmentReport
            // 
            tabPageDepartmentReport.Controls.Add(dataGridViewDepartmentReport);
            tabPageDepartmentReport.Controls.Add(panelDepartmentReport);
            tabPageDepartmentReport.Location = new Point(4, 24);
            tabPageDepartmentReport.Name = "tabPageDepartmentReport";
            tabPageDepartmentReport.Padding = new Padding(3);
            tabPageDepartmentReport.Size = new Size(1126, 583);
            tabPageDepartmentReport.TabIndex = 1;
            tabPageDepartmentReport.Text = "Отчёт по отделам";
            tabPageDepartmentReport.UseVisualStyleBackColor = true;
            // 
            // panelDepartmentReport
            // 
            panelDepartmentReport.Controls.Add(labelDateFrom2);
            panelDepartmentReport.Controls.Add(dateTimePickerFrom2);
            panelDepartmentReport.Controls.Add(labelDateTo2);
            panelDepartmentReport.Controls.Add(dateTimePickerTo2);
            panelDepartmentReport.Controls.Add(buttonCreateDepartmentReport);
            panelDepartmentReport.Controls.Add(buttonExcelDepartmentReport);
            panelDepartmentReport.Dock = DockStyle.Top;
            panelDepartmentReport.Location = new Point(3, 3);
            panelDepartmentReport.Name = "panelDepartmentReport";
            panelDepartmentReport.Size = new Size(1120, 75);
            panelDepartmentReport.TabIndex = 0;
            // 
            // labelDateFrom2
            // 
            labelDateFrom2.AutoSize = true;
            labelDateFrom2.Location = new Point(10, 12);
            labelDateFrom2.Name = "labelDateFrom2";
            labelDateFrom2.Size = new Size(74, 15);
            labelDateFrom2.TabIndex = 0;
            labelDateFrom2.Text = "Дата начала";
            // 
            // dateTimePickerFrom2
            // 
            dateTimePickerFrom2.Location = new Point(10, 38);
            dateTimePickerFrom2.Name = "dateTimePickerFrom2";
            dateTimePickerFrom2.Size = new Size(145, 23);
            dateTimePickerFrom2.TabIndex = 1;
            // 
            // labelDateTo2
            // 
            labelDateTo2.AutoSize = true;
            labelDateTo2.Location = new Point(175, 12);
            labelDateTo2.Name = "labelDateTo2";
            labelDateTo2.Size = new Size(69, 15);
            labelDateTo2.TabIndex = 2;
            labelDateTo2.Text = "Дата конца";
            // 
            // dateTimePickerTo2
            // 
            dateTimePickerTo2.Location = new Point(175, 38);
            dateTimePickerTo2.Name = "dateTimePickerTo2";
            dateTimePickerTo2.Size = new Size(145, 23);
            dateTimePickerTo2.TabIndex = 3;
            // 
            // buttonCreateDepartmentReport
            // 
            buttonCreateDepartmentReport.Location = new Point(345, 36);
            buttonCreateDepartmentReport.Name = "buttonCreateDepartmentReport";
            buttonCreateDepartmentReport.Size = new Size(130, 27);
            buttonCreateDepartmentReport.TabIndex = 4;
            buttonCreateDepartmentReport.Text = "Сформировать";
            buttonCreateDepartmentReport.UseVisualStyleBackColor = true;
            buttonCreateDepartmentReport.Click += buttonCreateDepartmentReport_Click;
            // 
            // buttonExcelDepartmentReport
            // 
            buttonExcelDepartmentReport.Location = new Point(490, 36);
            buttonExcelDepartmentReport.Name = "buttonExcelDepartmentReport";
            buttonExcelDepartmentReport.Size = new Size(90, 27);
            buttonExcelDepartmentReport.TabIndex = 5;
            buttonExcelDepartmentReport.Text = "Excel";
            buttonExcelDepartmentReport.UseVisualStyleBackColor = true;
            buttonExcelDepartmentReport.Click += buttonExcelDepartmentReport_Click;
            // 
            // dataGridViewDepartmentReport
            // 
            dataGridViewDepartmentReport.AllowUserToAddRows = false;
            dataGridViewDepartmentReport.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewDepartmentReport.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewDepartmentReport.Dock = DockStyle.Fill;
            dataGridViewDepartmentReport.Location = new Point(3, 78);
            dataGridViewDepartmentReport.MultiSelect = false;
            dataGridViewDepartmentReport.Name = "dataGridViewDepartmentReport";
            dataGridViewDepartmentReport.ReadOnly = true;
            dataGridViewDepartmentReport.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewDepartmentReport.Size = new Size(1120, 502);
            dataGridViewDepartmentReport.TabIndex = 1;
            // 
            // FormReports
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1134, 611);
            Controls.Add(tabControl1);
            Name = "FormReports";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Отчёты";
            tabControl1.ResumeLayout(false);
            tabPageTurnover.ResumeLayout(false);
            tabPageDepartmentReport.ResumeLayout(false);
            panelTurnover.ResumeLayout(false);
            panelTurnover.PerformLayout();
            panelDepartmentReport.ResumeLayout(false);
            panelDepartmentReport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTurnover).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewDepartmentReport).EndInit();
            ResumeLayout(false);
        }
    }
}

