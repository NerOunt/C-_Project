﻿using Npgsql;
using System.Data;

namespace WinFormsApp1
{
    public partial class FormDirectories : Form
    {
        private NpgsqlConnection con;

        private TabControl tabControl1;

        private DataGridView dataGridViewDepartments;
        private TextBox textBoxDepartmentName;
        private TextBox textBoxDepartmentDescription;

        private DataGridView dataGridViewProductTypes;
        private TextBox textBoxProductTypeName;

        private DataGridView dataGridViewProducts;
        private TextBox textBoxProductName;
        private TextBox textBoxProductEd;
        private ComboBox comboBoxProductType;

        private DataGridView dataGridViewSuppliers;
        private TextBox textBoxSupplierName;
        private TextBox textBoxSupplierAddress;
        private TextBox textBoxSupplierPhone;

        private DataGridView dataGridViewPaymentTypes;
        private TextBox textBoxPaymentTypeName;

        private DataGridView dataGridViewDepartmentProductTypes;
        private ComboBox comboBoxDepartmentForType;
        private ComboBox comboBoxProductTypeForDepartment;

        public FormDirectories()
        {
            InitializeComponent();
        }

        public FormDirectories(NpgsqlConnection con) : this()
        {
            this.con = con;
            Load += FormDirectories_Load;
        }

        private void BuildForm()
        {
            Text = "Справочники";
            Width = 1100;
            Height = 650;
            StartPosition = FormStartPosition.CenterParent;

            tabControl1 = new TabControl();
            tabControl1.Dock = DockStyle.Fill;
            Controls.Add(tabControl1);

            BuildDepartmentsTab();
            BuildProductTypesTab();
            BuildProductsTab();
            BuildSuppliersTab();
            BuildPaymentTypesTab();
            BuildDepartmentProductTypesTab();
        }

        private void BuildDepartmentsTab()
        {
            TabPage page = new TabPage("Отделы");
            Panel panel = CreateTopPanel();

            textBoxDepartmentName = AddTextBox(panel, "Название", 10, 10, 180);
            textBoxDepartmentDescription = AddTextBox(panel, "Описание", 230, 10, 250);
            AddButton(panel, "Добавить", 510, 8, buttonAddDepartment_Click);
            AddButton(panel, "Изменить", 610, 8, buttonEditDepartment_Click);
            AddButton(panel, "Удалить", 710, 8, buttonDeleteDepartment_Click);
            AddButton(panel, "Обновить", 810, 8, buttonRefreshDepartments_Click);

            dataGridViewDepartments = CreateGrid();
            dataGridViewDepartments.SelectionChanged += dataGridViewDepartments_SelectionChanged;
            page.Controls.Add(dataGridViewDepartments);
            page.Controls.Add(panel);
            tabControl1.TabPages.Add(page);
        }

        private void BuildProductTypesTab()
        {
            TabPage page = new TabPage("Виды товаров");
            Panel panel = CreateTopPanel();

            textBoxProductTypeName = AddTextBox(panel, "Название", 10, 10, 220);
            AddButton(panel, "Добавить", 260, 8, buttonAddProductType_Click);
            AddButton(panel, "Изменить", 360, 8, buttonEditProductType_Click);
            AddButton(panel, "Удалить", 460, 8, buttonDeleteProductType_Click);
            AddButton(panel, "Обновить", 560, 8, buttonRefreshProductTypes_Click);

            dataGridViewProductTypes = CreateGrid();
            dataGridViewProductTypes.SelectionChanged += dataGridViewProductTypes_SelectionChanged;
            page.Controls.Add(dataGridViewProductTypes);
            page.Controls.Add(panel);
            tabControl1.TabPages.Add(page);
        }

        private void BuildProductsTab()
        {
            TabPage page = new TabPage("Товары");
            Panel panel = CreateTopPanel();

            textBoxProductName = AddTextBox(panel, "Наименование", 10, 10, 190);
            textBoxProductEd = AddTextBox(panel, "Ед. изм.", 230, 10, 80);
            comboBoxProductType = AddComboBox(panel, "Вид товара", 340, 10, 180);
            AddButton(panel, "Добавить", 550, 8, buttonAddProduct_Click);
            AddButton(panel, "Изменить", 650, 8, buttonEditProduct_Click);
            AddButton(panel, "Удалить", 750, 8, buttonDeleteProduct_Click);
            AddButton(panel, "Обновить", 850, 8, buttonRefreshProducts_Click);

            dataGridViewProducts = CreateGrid();
            dataGridViewProducts.SelectionChanged += dataGridViewProducts_SelectionChanged;
            page.Controls.Add(dataGridViewProducts);
            page.Controls.Add(panel);
            tabControl1.TabPages.Add(page);
        }

        private void BuildSuppliersTab()
        {
            TabPage page = new TabPage("Поставщики");
            Panel panel = CreateTopPanel();

            textBoxSupplierName = AddTextBox(panel, "Название", 10, 10, 160);
            textBoxSupplierAddress = AddTextBox(panel, "Адрес", 200, 10, 220);
            textBoxSupplierPhone = AddTextBox(panel, "Телефон", 450, 10, 130);
            AddButton(panel, "Добавить", 610, 8, buttonAddSupplier_Click);
            AddButton(panel, "Изменить", 710, 8, buttonEditSupplier_Click);
            AddButton(panel, "Удалить", 810, 8, buttonDeleteSupplier_Click);
            AddButton(panel, "Обновить", 910, 8, buttonRefreshSuppliers_Click);

            dataGridViewSuppliers = CreateGrid();
            dataGridViewSuppliers.SelectionChanged += dataGridViewSuppliers_SelectionChanged;
            page.Controls.Add(dataGridViewSuppliers);
            page.Controls.Add(panel);
            tabControl1.TabPages.Add(page);
        }

        private void BuildPaymentTypesTab()
        {
            TabPage page = new TabPage("Типы оплаты");
            Panel panel = CreateTopPanel();

            textBoxPaymentTypeName = AddTextBox(panel, "Название", 10, 10, 220);
            AddButton(panel, "Добавить", 260, 8, buttonAddPaymentType_Click);
            AddButton(panel, "Изменить", 360, 8, buttonEditPaymentType_Click);
            AddButton(panel, "Удалить", 460, 8, buttonDeletePaymentType_Click);
            AddButton(panel, "Обновить", 560, 8, buttonRefreshPaymentTypes_Click);

            dataGridViewPaymentTypes = CreateGrid();
            dataGridViewPaymentTypes.SelectionChanged += dataGridViewPaymentTypes_SelectionChanged;
            page.Controls.Add(dataGridViewPaymentTypes);
            page.Controls.Add(panel);
            tabControl1.TabPages.Add(page);
        }

        private void BuildDepartmentProductTypesTab()
        {
            TabPage page = new TabPage("Виды по отделам");
            Panel panel = CreateTopPanel();

            comboBoxDepartmentForType = AddComboBox(panel, "Отдел", 10, 10, 220);
            comboBoxProductTypeForDepartment = AddComboBox(panel, "Вид товара", 260, 10, 220);
            AddButton(panel, "Добавить", 510, 8, buttonAddDepartmentProductType_Click);
            AddButton(panel, "Удалить", 610, 8, buttonDeleteDepartmentProductType_Click);
            AddButton(panel, "Обновить", 710, 8, buttonRefreshDepartmentProductTypes_Click);

            dataGridViewDepartmentProductTypes = CreateGrid();
            page.Controls.Add(dataGridViewDepartmentProductTypes);
            page.Controls.Add(panel);
            tabControl1.TabPages.Add(page);
        }

        private Panel CreateTopPanel()
        {
            Panel panel = new Panel();
            panel.Dock = DockStyle.Top;
            panel.Height = 70;
            return panel;
        }

        private DataGridView CreateGrid()
        {
            DataGridView grid = new DataGridView();
            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.AllowUserToAddRows = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            return grid;
        }

        private TextBox AddTextBox(Control parent, string text, int left, int top, int width)
        {
            Label label = new Label();
            label.Text = text;
            label.Left = left;
            label.Top = top;
            label.Width = width;
            parent.Controls.Add(label);

            TextBox textBox = new TextBox();
            textBox.Left = left;
            textBox.Top = top + 25;
            textBox.Width = width;
            parent.Controls.Add(textBox);
            return textBox;
        }

        private ComboBox AddComboBox(Control parent, string text, int left, int top, int width)
        {
            Label label = new Label();
            label.Text = text;
            label.Left = left;
            label.Top = top;
            label.Width = width;
            parent.Controls.Add(label);

            ComboBox comboBox = new ComboBox();
            comboBox.Left = left;
            comboBox.Top = top + 25;
            comboBox.Width = width;
            comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            parent.Controls.Add(comboBox);
            return comboBox;
        }

        private Button AddButton(Control parent, string text, int left, int top, EventHandler click)
        {
            Button button = new Button();
            button.Text = text;
            button.Left = left;
            button.Top = top + 25;
            button.Width = 90;
            button.Height = 28;
            button.Click += click;
            parent.Controls.Add(button);
            return button;
        }

        private void FormDirectories_Load(object sender, EventArgs e)
        {
            LoadAll();
        }

        private void LoadAll()
        {
            LoadDepartments();
            LoadProductTypes();
            LoadProductTypesCombo();
            LoadProducts();
            LoadSuppliers();
            LoadPaymentTypes();
            LoadDepartmentsCombo();
            LoadDepartmentProductTypes();
        }

        private void LoadCombo(ComboBox comboBox, string sql)
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataTable table = new DataTable();
                adapter.Fill(table);
                comboBox.DataSource = table;
                comboBox.DisplayMember = "name";
                comboBox.ValueMember = "id";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private int GetId(DataGridView grid)
        {
            if (grid.CurrentRow == null) return -1;
            return Convert.ToInt32(grid.CurrentRow.Cells["ID"].Value);
        }

        private int GetComboId(ComboBox comboBox)
        {
            if (comboBox.SelectedValue == null) return -1;
            if (comboBox.SelectedValue is DataRowView)
            {
                DataRowView row = (DataRowView)comboBox.SelectedValue;
                return Convert.ToInt32(row["id"]);
            }
            return Convert.ToInt32(comboBox.SelectedValue);
        }

        private void LoadDepartments()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id AS ID, name, description FROM departments ORDER BY id;", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewDepartments.DataSource = ds.Tables[0];
                dataGridViewDepartments.Columns["ID"].HeaderText = "Номер";
                dataGridViewDepartments.Columns["name"].HeaderText = "Название";
                dataGridViewDepartments.Columns["description"].HeaderText = "Описание";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadProductTypes()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id AS ID, name FROM product_types ORDER BY id;", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewProductTypes.DataSource = ds.Tables[0];
                dataGridViewProductTypes.Columns["ID"].HeaderText = "Номер";
                dataGridViewProductTypes.Columns["name"].HeaderText = "Название";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadProductTypesCombo()
        {
            LoadCombo(comboBoxProductType, "SELECT id, name FROM product_types ORDER BY name;");
            LoadCombo(comboBoxProductTypeForDepartment, "SELECT id, name FROM product_types ORDER BY name;");
        }

        private void LoadDepartmentsCombo()
        {
            LoadCombo(comboBoxDepartmentForType, "SELECT id, name FROM departments ORDER BY name;");
        }

        private void LoadProducts()
        {
            try
            {
                string sql =
                    "SELECT products.id AS ID, products.name AS name, products.ed AS ed, " +
                    "product_types.name AS product_type, products.product_type_id AS product_type_id " +
                    "FROM products JOIN product_types ON products.product_type_id = product_types.id " +
                    "ORDER BY products.id;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewProducts.DataSource = ds.Tables[0];
                dataGridViewProducts.Columns["ID"].HeaderText = "Номер";
                dataGridViewProducts.Columns["name"].HeaderText = "Наименование";
                dataGridViewProducts.Columns["ed"].HeaderText = "Ед. изм.";
                dataGridViewProducts.Columns["product_type"].HeaderText = "Вид товара";
                dataGridViewProducts.Columns["product_type_id"].Visible = false;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadSuppliers()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id AS ID, name, address, phone FROM suppliers ORDER BY id;", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewSuppliers.DataSource = ds.Tables[0];
                dataGridViewSuppliers.Columns["ID"].HeaderText = "Номер";
                dataGridViewSuppliers.Columns["name"].HeaderText = "Название";
                dataGridViewSuppliers.Columns["address"].HeaderText = "Адрес";
                dataGridViewSuppliers.Columns["phone"].HeaderText = "Телефон";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadPaymentTypes()
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT id AS ID, name FROM payment_types ORDER BY id;", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewPaymentTypes.DataSource = ds.Tables[0];
                dataGridViewPaymentTypes.Columns["ID"].HeaderText = "Номер";
                dataGridViewPaymentTypes.Columns["name"].HeaderText = "Название";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadDepartmentProductTypes()
        {
            try
            {
                string sql =
                    "SELECT dpt.id AS ID, departments.name AS department, product_types.name AS product_type " +
                    "FROM department_product_types dpt " +
                    "JOIN departments ON dpt.department_id = departments.id " +
                    "JOIN product_types ON dpt.product_type_id = product_types.id " +
                    "ORDER BY departments.name, product_types.name;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewDepartmentProductTypes.DataSource = ds.Tables[0];
                dataGridViewDepartmentProductTypes.Columns["ID"].HeaderText = "Номер";
                dataGridViewDepartmentProductTypes.Columns["department"].HeaderText = "Отдел";
                dataGridViewDepartmentProductTypes.Columns["product_type"].HeaderText = "Вид товара";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void dataGridViewDepartments_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewDepartments.CurrentRow == null) return;
            textBoxDepartmentName.Text = Convert.ToString(dataGridViewDepartments.CurrentRow.Cells["name"].Value);
            textBoxDepartmentDescription.Text = Convert.ToString(dataGridViewDepartments.CurrentRow.Cells["description"].Value);
        }

        private void buttonAddDepartment_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO departments (name, description) VALUES (:name, :description);", con);
                cmd.Parameters.AddWithValue("name", textBoxDepartmentName.Text);
                cmd.Parameters.AddWithValue("description", textBoxDepartmentDescription.Text);
                cmd.ExecuteNonQuery();
                LoadDepartments();
                LoadDepartmentsCombo();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonEditDepartment_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewDepartments);
            if (id == -1) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE departments SET name = :name, description = :description WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", textBoxDepartmentName.Text);
                cmd.Parameters.AddWithValue("description", textBoxDepartmentDescription.Text);
                cmd.ExecuteNonQuery();
                LoadDepartments();
                LoadDepartmentsCombo();
                LoadDepartmentProductTypes();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonDeleteDepartment_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewDepartments);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM departments WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadAll();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void dataGridViewProductTypes_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewProductTypes.CurrentRow == null) return;
            textBoxProductTypeName.Text = Convert.ToString(dataGridViewProductTypes.CurrentRow.Cells["name"].Value);
        }

        private void buttonAddProductType_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO product_types (name) VALUES (:name);", con);
                cmd.Parameters.AddWithValue("name", textBoxProductTypeName.Text);
                cmd.ExecuteNonQuery();
                LoadProductTypes();
                LoadProductTypesCombo();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonEditProductType_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewProductTypes);
            if (id == -1) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE product_types SET name = :name WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", textBoxProductTypeName.Text);
                cmd.ExecuteNonQuery();
                LoadProductTypes();
                LoadProductTypesCombo();
                LoadProducts();
                LoadDepartmentProductTypes();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonDeleteProductType_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewProductTypes);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM product_types WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadAll();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void dataGridViewProducts_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewProducts.CurrentRow == null) return;
            textBoxProductName.Text = Convert.ToString(dataGridViewProducts.CurrentRow.Cells["name"].Value);
            textBoxProductEd.Text = Convert.ToString(dataGridViewProducts.CurrentRow.Cells["ed"].Value);
            comboBoxProductType.SelectedValue = Convert.ToInt32(dataGridViewProducts.CurrentRow.Cells["product_type_id"].Value);
        }

        private void buttonAddProduct_Click(object sender, EventArgs e)
        {
            int productTypeId = GetComboId(comboBoxProductType);
            if (productTypeId == -1) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO products (name, ed, product_type_id) VALUES (:name, :ed, :product_type_id);", con);
                cmd.Parameters.AddWithValue("name", textBoxProductName.Text);
                cmd.Parameters.AddWithValue("ed", textBoxProductEd.Text);
                cmd.Parameters.AddWithValue("product_type_id", productTypeId);
                cmd.ExecuteNonQuery();
                LoadProducts();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonEditProduct_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewProducts);
            int productTypeId = GetComboId(comboBoxProductType);
            if (id == -1 || productTypeId == -1) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE products SET name = :name, ed = :ed, product_type_id = :product_type_id WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", textBoxProductName.Text);
                cmd.Parameters.AddWithValue("ed", textBoxProductEd.Text);
                cmd.Parameters.AddWithValue("product_type_id", productTypeId);
                cmd.ExecuteNonQuery();
                LoadProducts();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonDeleteProduct_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewProducts);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM products WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadProducts();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void dataGridViewSuppliers_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewSuppliers.CurrentRow == null) return;
            textBoxSupplierName.Text = Convert.ToString(dataGridViewSuppliers.CurrentRow.Cells["name"].Value);
            textBoxSupplierAddress.Text = Convert.ToString(dataGridViewSuppliers.CurrentRow.Cells["address"].Value);
            textBoxSupplierPhone.Text = Convert.ToString(dataGridViewSuppliers.CurrentRow.Cells["phone"].Value);
        }

        private void buttonAddSupplier_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO suppliers (name, address, phone) VALUES (:name, :address, :phone);", con);
                cmd.Parameters.AddWithValue("name", textBoxSupplierName.Text);
                cmd.Parameters.AddWithValue("address", textBoxSupplierAddress.Text);
                cmd.Parameters.AddWithValue("phone", textBoxSupplierPhone.Text);
                cmd.ExecuteNonQuery();
                LoadSuppliers();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonEditSupplier_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewSuppliers);
            if (id == -1) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE suppliers SET name = :name, address = :address, phone = :phone WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", textBoxSupplierName.Text);
                cmd.Parameters.AddWithValue("address", textBoxSupplierAddress.Text);
                cmd.Parameters.AddWithValue("phone", textBoxSupplierPhone.Text);
                cmd.ExecuteNonQuery();
                LoadSuppliers();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonDeleteSupplier_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewSuppliers);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM suppliers WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadSuppliers();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void dataGridViewPaymentTypes_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewPaymentTypes.CurrentRow == null) return;
            textBoxPaymentTypeName.Text = Convert.ToString(dataGridViewPaymentTypes.CurrentRow.Cells["name"].Value);
        }

        private void buttonAddPaymentType_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO payment_types (name) VALUES (:name);", con);
                cmd.Parameters.AddWithValue("name", textBoxPaymentTypeName.Text);
                cmd.ExecuteNonQuery();
                LoadPaymentTypes();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonEditPaymentType_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewPaymentTypes);
            if (id == -1) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE payment_types SET name = :name WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", textBoxPaymentTypeName.Text);
                cmd.ExecuteNonQuery();
                LoadPaymentTypes();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonDeletePaymentType_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewPaymentTypes);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM payment_types WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadPaymentTypes();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonAddDepartmentProductType_Click(object sender, EventArgs e)
        {
            int departmentId = GetComboId(comboBoxDepartmentForType);
            int productTypeId = GetComboId(comboBoxProductTypeForDepartment);
            if (departmentId == -1 || productTypeId == -1) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO department_product_types (department_id, product_type_id) VALUES (:department_id, :product_type_id);", con);
                cmd.Parameters.AddWithValue("department_id", departmentId);
                cmd.Parameters.AddWithValue("product_type_id", productTypeId);
                cmd.ExecuteNonQuery();
                LoadDepartmentProductTypes();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonDeleteDepartmentProductType_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewDepartmentProductTypes);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM department_product_types WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadDepartmentProductTypes();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonRefreshDepartments_Click(object sender, EventArgs e) { LoadDepartments(); LoadDepartmentsCombo(); }
        private void buttonRefreshProductTypes_Click(object sender, EventArgs e) { LoadProductTypes(); LoadProductTypesCombo(); }
        private void buttonRefreshProducts_Click(object sender, EventArgs e) { LoadProductTypesCombo(); LoadProducts(); }
        private void buttonRefreshSuppliers_Click(object sender, EventArgs e) { LoadSuppliers(); }
        private void buttonRefreshPaymentTypes_Click(object sender, EventArgs e) { LoadPaymentTypes(); }
        private void buttonRefreshDepartmentProductTypes_Click(object sender, EventArgs e) { LoadDepartmentsCombo(); LoadProductTypesCombo(); LoadDepartmentProductTypes(); }
    }
}

