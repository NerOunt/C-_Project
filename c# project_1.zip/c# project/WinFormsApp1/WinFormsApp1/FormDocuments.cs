﻿using Npgsql;
using System.Data;

namespace WinFormsApp1
{
    public partial class FormDocuments : Form
    {
        private NpgsqlConnection con;

        private TabControl tabControl1;

        private DataGridView dataGridViewIncomingInvoices;
        private DataGridView dataGridViewIncomingItems;
        private DateTimePicker dateTimePickerIncomingDate;
        private ComboBox comboBoxIncomingSupplier;
        private ComboBox comboBoxIncomingDepartment;
        private ComboBox comboBoxIncomingProduct;
        private TextBox textBoxIncomingQuantity;
        private TextBox textBoxIncomingPrice;

        private DataGridView dataGridViewSalesReceipts;
        private DataGridView dataGridViewSalesItems;
        private DateTimePicker dateTimePickerSalesDate;
        private ComboBox comboBoxSalesDepartment;
        private ComboBox comboBoxSalesPaymentType;
        private ComboBox comboBoxSalesProduct;
        private TextBox textBoxSalesQuantity;
        private TextBox textBoxSalesPrice;

        public FormDocuments()
        {
            InitializeComponent();
        }

        public FormDocuments(NpgsqlConnection con) : this()
        {
            this.con = con;
            Load += FormDocuments_Load;
        }

        private void BuildForm()
        {
            Text = "Документы";
            Width = 1200;
            Height = 720;
            StartPosition = FormStartPosition.CenterParent;

            tabControl1 = new TabControl();
            tabControl1.Dock = DockStyle.Fill;
            Controls.Add(tabControl1);

            BuildIncomingTab();
            BuildSalesTab();
        }

        private void BuildIncomingTab()
        {
            TabPage page = new TabPage("Приходные накладные");
            Panel topPanel = CreatePanel(120, DockStyle.Top);
            Panel centerPanel = new Panel();
            centerPanel.Dock = DockStyle.Fill;

            dateTimePickerIncomingDate = AddDateTimePicker(topPanel, "Дата", 10, 10, 140);
            comboBoxIncomingSupplier = AddComboBox(topPanel, "Поставщик", 170, 10, 180);
            comboBoxIncomingDepartment = AddComboBox(topPanel, "Отдел", 370, 10, 180);
            comboBoxIncomingDepartment.SelectedIndexChanged += comboBoxIncomingDepartment_SelectedIndexChanged;
            AddButton(topPanel, "Добавить накладную", 570, 35, 145, buttonAddIncomingInvoice_Click);
            AddButton(topPanel, "Удалить накладную", 725, 35, 135, buttonDeleteIncomingInvoice_Click);
            AddButton(topPanel, "Обновить", 870, 35, 90, buttonRefreshIncoming_Click);

            comboBoxIncomingProduct = AddComboBox(topPanel, "Товар", 10, 55, 220);
            textBoxIncomingQuantity = AddTextBox(topPanel, "Количество", 250, 55, 100);
            textBoxIncomingPrice = AddTextBox(topPanel, "Цена", 370, 55, 100);
            AddButton(topPanel, "Добавить товар", 490, 80, 120, buttonAddIncomingItem_Click);
            AddButton(topPanel, "Удалить товар", 620, 80, 110, buttonDeleteIncomingItem_Click);

            dataGridViewIncomingInvoices = CreateGrid();
            dataGridViewIncomingItems = CreateGrid();
            dataGridViewIncomingInvoices.SelectionChanged += dataGridViewIncomingInvoices_SelectionChanged;

            SplitContainer split = new SplitContainer();
            split.Dock = DockStyle.Fill;
            split.Orientation = Orientation.Horizontal;
            split.SplitterDistance = 300;
            split.Panel1.Controls.Add(dataGridViewIncomingInvoices);
            split.Panel2.Controls.Add(dataGridViewIncomingItems);
            centerPanel.Controls.Add(split);

            page.Controls.Add(centerPanel);
            page.Controls.Add(topPanel);
            tabControl1.TabPages.Add(page);
        }

        private void BuildSalesTab()
        {
            TabPage page = new TabPage("Продажи");
            Panel topPanel = CreatePanel(120, DockStyle.Top);
            Panel centerPanel = new Panel();
            centerPanel.Dock = DockStyle.Fill;

            dateTimePickerSalesDate = AddDateTimePicker(topPanel, "Дата", 10, 10, 140);
            comboBoxSalesDepartment = AddComboBox(topPanel, "Отдел", 170, 10, 180);
            comboBoxSalesDepartment.SelectedIndexChanged += comboBoxSalesDepartment_SelectedIndexChanged;
            comboBoxSalesPaymentType = AddComboBox(topPanel, "Тип оплаты", 370, 10, 180);
            AddButton(topPanel, "Добавить чек", 570, 35, 110, buttonAddSalesReceipt_Click);
            AddButton(topPanel, "Удалить чек", 690, 35, 105, buttonDeleteSalesReceipt_Click);
            AddButton(topPanel, "Обновить", 805, 35, 90, buttonRefreshSales_Click);

            comboBoxSalesProduct = AddComboBox(topPanel, "Товар", 10, 55, 220);
            textBoxSalesQuantity = AddTextBox(topPanel, "Количество", 250, 55, 100);
            textBoxSalesPrice = AddTextBox(topPanel, "Цена", 370, 55, 100);
            AddButton(topPanel, "Добавить товар", 490, 80, 120, buttonAddSalesItem_Click);
            AddButton(topPanel, "Удалить товар", 620, 80, 110, buttonDeleteSalesItem_Click);

            dataGridViewSalesReceipts = CreateGrid();
            dataGridViewSalesItems = CreateGrid();
            dataGridViewSalesReceipts.SelectionChanged += dataGridViewSalesReceipts_SelectionChanged;

            SplitContainer split = new SplitContainer();
            split.Dock = DockStyle.Fill;
            split.Orientation = Orientation.Horizontal;
            split.SplitterDistance = 300;
            split.Panel1.Controls.Add(dataGridViewSalesReceipts);
            split.Panel2.Controls.Add(dataGridViewSalesItems);
            centerPanel.Controls.Add(split);

            page.Controls.Add(centerPanel);
            page.Controls.Add(topPanel);
            tabControl1.TabPages.Add(page);
        }

        private Panel CreatePanel(int height, DockStyle dock)
        {
            Panel panel = new Panel();
            panel.Height = height;
            panel.Dock = dock;
            return panel;
        }

        private DataGridView CreateGrid()
        {
            DataGridView grid = new DataGridView();
            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.AllowUserToAddRows = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            return grid;
        }

        private DateTimePicker AddDateTimePicker(Control parent, string text, int left, int top, int width)
        {
            Label label = new Label();
            label.Text = text;
            label.Left = left;
            label.Top = top;
            label.Width = width;
            parent.Controls.Add(label);

            DateTimePicker picker = new DateTimePicker();
            picker.Left = left;
            picker.Top = top + 25;
            picker.Width = width;
            parent.Controls.Add(picker);
            return picker;
        }

        private ComboBox AddComboBox(Control parent, string text, int left, int top, int width)
        {
            Label label = new Label();
            label.Text = text;
            label.Left = left;
            label.Top = top;
            label.Width = width;
            parent.Controls.Add(label);

            ComboBox comboBox = new ComboBox();
            comboBox.Left = left;
            comboBox.Top = top + 25;
            comboBox.Width = width;
            comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            parent.Controls.Add(comboBox);
            return comboBox;
        }

        private TextBox AddTextBox(Control parent, string text, int left, int top, int width)
        {
            Label label = new Label();
            label.Text = text;
            label.Left = left;
            label.Top = top;
            label.Width = width;
            parent.Controls.Add(label);

            TextBox textBox = new TextBox();
            textBox.Left = left;
            textBox.Top = top + 25;
            textBox.Width = width;
            parent.Controls.Add(textBox);
            return textBox;
        }

        private Button AddButton(Control parent, string text, int left, int top, int width, EventHandler click)
        {
            Button button = new Button();
            button.Text = text;
            button.Left = left;
            button.Top = top;
            button.Width = width;
            button.Height = 28;
            button.Click += click;
            parent.Controls.Add(button);
            return button;
        }

        private void FormDocuments_Load(object sender, EventArgs e)
        {
            LoadCombos();
            LoadIncomingInvoices();
            LoadSalesReceipts();
        }

        private int GetId(DataGridView grid)
        {
            if (grid.CurrentRow == null) return -1;
            return Convert.ToInt32(grid.CurrentRow.Cells["ID"].Value);
        }

        private int GetComboId(ComboBox comboBox)
        {
            if (comboBox.SelectedValue == null) return -1;
            if (comboBox.SelectedValue is DataRowView)
            {
                DataRowView row = (DataRowView)comboBox.SelectedValue;
                return Convert.ToInt32(row["id"]);
            }
            return Convert.ToInt32(comboBox.SelectedValue);
        }

        private void LoadCombos()
        {
            LoadCombo(comboBoxIncomingSupplier, "SELECT id, name FROM suppliers ORDER BY name;");
            LoadCombo(comboBoxIncomingDepartment, "SELECT id, name FROM departments ORDER BY name;");
            LoadCombo(comboBoxSalesDepartment, "SELECT id, name FROM departments ORDER BY name;");
            LoadCombo(comboBoxSalesPaymentType, "SELECT id, name FROM payment_types ORDER BY name;");
            LoadIncomingProductsByDepartment();
            LoadSalesProductsByDepartment();
        }

        private void LoadCombo(ComboBox comboBox, string sql)
        {
            try
            {
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataTable table = new DataTable();
                adapter.Fill(table);
                comboBox.DataSource = table;
                comboBox.DisplayMember = "name";
                comboBox.ValueMember = "id";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadProductsByDepartment(ComboBox productComboBox, int departmentId)
        {
            try
            {
                if (departmentId == -1)
                {
                    productComboBox.DataSource = null;
                    return;
                }

                string sql =
                    "SELECT products.id, products.name " +
                    "FROM products " +
                    "JOIN department_product_types ON products.product_type_id = department_product_types.product_type_id " +
                    "WHERE department_product_types.department_id = :department_id " +
                    "ORDER BY products.name;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                adapter.SelectCommand.Parameters.AddWithValue("department_id", departmentId);
                DataTable table = new DataTable();
                adapter.Fill(table);
                productComboBox.DataSource = table;
                productComboBox.DisplayMember = "name";
                productComboBox.ValueMember = "id";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadIncomingProductsByDepartment()
        {
            LoadProductsByDepartment(comboBoxIncomingProduct, GetComboId(comboBoxIncomingDepartment));
        }

        private void LoadSalesProductsByDepartment()
        {
            LoadProductsByDepartment(comboBoxSalesProduct, GetComboId(comboBoxSalesDepartment));
        }

        private void comboBoxIncomingDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadIncomingProductsByDepartment();
        }

        private void comboBoxSalesDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadSalesProductsByDepartment();
        }

        private void LoadIncomingInvoices()
        {
            try
            {
                string sql =
                    "SELECT incoming_invoices.id AS ID, incoming_invoices.invoice_date AS data, " +
                    "suppliers.name AS supplier, departments.name AS department, incoming_invoices.total_sum AS total_sum, " +
                    "incoming_invoices.supplier_id, incoming_invoices.department_id " +
                    "FROM incoming_invoices " +
                    "JOIN suppliers ON incoming_invoices.supplier_id = suppliers.id " +
                    "JOIN departments ON incoming_invoices.department_id = departments.id " +
                    "ORDER BY incoming_invoices.id;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewIncomingInvoices.DataSource = ds.Tables[0];
                dataGridViewIncomingInvoices.Columns["ID"].HeaderText = "Номер";
                dataGridViewIncomingInvoices.Columns["data"].HeaderText = "Дата";
                dataGridViewIncomingInvoices.Columns["supplier"].HeaderText = "Поставщик";
                dataGridViewIncomingInvoices.Columns["department"].HeaderText = "Отдел";
                dataGridViewIncomingInvoices.Columns["total_sum"].HeaderText = "Сумма";
                dataGridViewIncomingInvoices.Columns["supplier_id"].Visible = false;
                dataGridViewIncomingInvoices.Columns["department_id"].Visible = false;
                LoadIncomingItems();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadIncomingItems()
        {
            int invoiceId = GetId(dataGridViewIncomingInvoices);
            if (invoiceId == -1)
            {
                dataGridViewIncomingItems.DataSource = null;
                return;
            }

            try
            {
                string sql =
                    "SELECT incoming_invoice_items.id AS ID, products.name AS product, products.ed AS ed, " +
                    "incoming_invoice_items.quantity AS quantity, incoming_invoice_items.price AS price, " +
                    "incoming_invoice_items.quantity * incoming_invoice_items.price AS sum " +
                    "FROM incoming_invoice_items " +
                    "JOIN products ON incoming_invoice_items.product_id = products.id " +
                    "WHERE incoming_invoice_items.incoming_invoice_id = :invoice_id " +
                    "ORDER BY incoming_invoice_items.id;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                adapter.SelectCommand.Parameters.AddWithValue("invoice_id", invoiceId);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridViewIncomingItems.DataSource = table;
                SetItemHeaders(dataGridViewIncomingItems);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void dataGridViewIncomingInvoices_SelectionChanged(object sender, EventArgs e)
        {
            LoadIncomingItems();
        }

        private void buttonAddIncomingInvoice_Click(object sender, EventArgs e)
        {
            int supplierId = GetComboId(comboBoxIncomingSupplier);
            int departmentId = GetComboId(comboBoxIncomingDepartment);
            if (supplierId == -1 || departmentId == -1) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand(
                    "INSERT INTO incoming_invoices (supplier_id, department_id, invoice_date, total_sum) " +
                    "VALUES (:supplier_id, :department_id, :invoice_date, 0);", con);
                cmd.Parameters.AddWithValue("supplier_id", supplierId);
                cmd.Parameters.AddWithValue("department_id", departmentId);
                cmd.Parameters.AddWithValue("invoice_date", dateTimePickerIncomingDate.Value.Date);
                cmd.ExecuteNonQuery();
                LoadIncomingInvoices();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonDeleteIncomingInvoice_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewIncomingInvoices);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM incoming_invoices WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadIncomingInvoices();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonAddIncomingItem_Click(object sender, EventArgs e)
        {
            int invoiceId = GetId(dataGridViewIncomingInvoices);
            int productId = GetComboId(comboBoxIncomingProduct);
            decimal quantity;
            decimal price;

            if (invoiceId == -1 || productId == -1) return;
            if (!decimal.TryParse(textBoxIncomingQuantity.Text, out quantity)) return;
            if (!decimal.TryParse(textBoxIncomingPrice.Text, out price)) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand(
                    "INSERT INTO incoming_invoice_items (incoming_invoice_id, product_id, quantity, price) " +
                    "VALUES (:incoming_invoice_id, :product_id, :quantity, :price);", con);
                cmd.Parameters.AddWithValue("incoming_invoice_id", invoiceId);
                cmd.Parameters.AddWithValue("product_id", productId);
                cmd.Parameters.AddWithValue("quantity", quantity);
                cmd.Parameters.AddWithValue("price", price);
                cmd.ExecuteNonQuery();
                LoadIncomingInvoices();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonDeleteIncomingItem_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewIncomingItems);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM incoming_invoice_items WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadIncomingInvoices();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadSalesReceipts()
        {
            try
            {
                string sql =
                    "SELECT sales_receipts.id AS ID, sales_receipts.receipt_date AS data, " +
                    "departments.name AS department, payment_types.name AS payment_type, sales_receipts.total_sum AS total_sum, " +
                    "sales_receipts.department_id, sales_receipts.payment_type_id " +
                    "FROM sales_receipts " +
                    "JOIN departments ON sales_receipts.department_id = departments.id " +
                    "JOIN payment_types ON sales_receipts.payment_type_id = payment_types.id " +
                    "ORDER BY sales_receipts.id;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dataGridViewSalesReceipts.DataSource = ds.Tables[0];
                dataGridViewSalesReceipts.Columns["ID"].HeaderText = "Номер";
                dataGridViewSalesReceipts.Columns["data"].HeaderText = "Дата";
                dataGridViewSalesReceipts.Columns["department"].HeaderText = "Отдел";
                dataGridViewSalesReceipts.Columns["payment_type"].HeaderText = "Тип оплаты";
                dataGridViewSalesReceipts.Columns["total_sum"].HeaderText = "Сумма";
                dataGridViewSalesReceipts.Columns["department_id"].Visible = false;
                dataGridViewSalesReceipts.Columns["payment_type_id"].Visible = false;
                LoadSalesItems();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadSalesItems()
        {
            int receiptId = GetId(dataGridViewSalesReceipts);
            if (receiptId == -1)
            {
                dataGridViewSalesItems.DataSource = null;
                return;
            }

            try
            {
                string sql =
                    "SELECT sales_receipt_items.id AS ID, products.name AS product, products.ed AS ed, " +
                    "sales_receipt_items.quantity AS quantity, sales_receipt_items.price AS price, " +
                    "sales_receipt_items.quantity * sales_receipt_items.price AS sum " +
                    "FROM sales_receipt_items " +
                    "JOIN products ON sales_receipt_items.product_id = products.id " +
                    "WHERE sales_receipt_items.sales_receipt_id = :receipt_id " +
                    "ORDER BY sales_receipt_items.id;";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, con);
                adapter.SelectCommand.Parameters.AddWithValue("receipt_id", receiptId);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridViewSalesItems.DataSource = table;
                SetItemHeaders(dataGridViewSalesItems);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void dataGridViewSalesReceipts_SelectionChanged(object sender, EventArgs e)
        {
            LoadSalesItems();
        }

        private void buttonAddSalesReceipt_Click(object sender, EventArgs e)
        {
            int departmentId = GetComboId(comboBoxSalesDepartment);
            int paymentTypeId = GetComboId(comboBoxSalesPaymentType);
            if (departmentId == -1 || paymentTypeId == -1) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand(
                    "INSERT INTO sales_receipts (department_id, payment_type_id, receipt_date, total_sum) " +
                    "VALUES (:department_id, :payment_type_id, :receipt_date, 0);", con);
                cmd.Parameters.AddWithValue("department_id", departmentId);
                cmd.Parameters.AddWithValue("payment_type_id", paymentTypeId);
                cmd.Parameters.AddWithValue("receipt_date", dateTimePickerSalesDate.Value.Date);
                cmd.ExecuteNonQuery();
                LoadSalesReceipts();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonDeleteSalesReceipt_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewSalesReceipts);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM sales_receipts WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadSalesReceipts();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonAddSalesItem_Click(object sender, EventArgs e)
        {
            int receiptId = GetId(dataGridViewSalesReceipts);
            int productId = GetComboId(comboBoxSalesProduct);
            decimal quantity;
            decimal price;

            if (receiptId == -1 || productId == -1) return;
            if (!decimal.TryParse(textBoxSalesQuantity.Text, out quantity)) return;
            if (!decimal.TryParse(textBoxSalesPrice.Text, out price)) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand(
                    "INSERT INTO sales_receipt_items (sales_receipt_id, product_id, quantity, price) " +
                    "VALUES (:sales_receipt_id, :product_id, :quantity, :price);", con);
                cmd.Parameters.AddWithValue("sales_receipt_id", receiptId);
                cmd.Parameters.AddWithValue("product_id", productId);
                cmd.Parameters.AddWithValue("quantity", quantity);
                cmd.Parameters.AddWithValue("price", price);
                cmd.ExecuteNonQuery();
                LoadSalesReceipts();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void buttonDeleteSalesItem_Click(object sender, EventArgs e)
        {
            int id = GetId(dataGridViewSalesItems);
            if (id == -1) return;
            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM sales_receipt_items WHERE id = :id;", con);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
                LoadSalesReceipts();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void SetItemHeaders(DataGridView grid)
        {
            if (grid.Columns.Count == 0) return;
            grid.Columns["ID"].HeaderText = "Номер";
            grid.Columns["product"].HeaderText = "Товар";
            grid.Columns["ed"].HeaderText = "Ед. изм.";
            grid.Columns["quantity"].HeaderText = "Количество";
            grid.Columns["price"].HeaderText = "Цена";
            grid.Columns["sum"].HeaderText = "Сумма";
        }

        private void buttonRefreshIncoming_Click(object sender, EventArgs e)
        {
            LoadCombos();
            LoadIncomingInvoices();
        }

        private void buttonRefreshSales_Click(object sender, EventArgs e)
        {
            LoadCombos();
            LoadSalesReceipts();
        }
    }
}

