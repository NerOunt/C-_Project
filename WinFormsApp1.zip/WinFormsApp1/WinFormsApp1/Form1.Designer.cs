﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Load = new Button();
            SuspendLayout();
            // 
            // Load
            // 
            Load.Location = new Point(288, 185);
            Load.Name = "Load";
            Load.Size = new Size(75, 23);
            Load.TabIndex = 0;
            Load.Text = "Товары";
            Load.UseVisualStyleBackColor = true;
            Load.Click += Load_Click;
            // 
            // Form1
            // 
            ClientSize = new Size(803, 360);
            Controls.Add(Load);
            Name = "Form1";
            ResumeLayout(false);


        }

        #endregion

        private Button Load;
    }
}
